System.register([],(function(e){"use strict";return{execute:function(){e("default","assets/bullet.release.wasm-10f8cbd4.wasm")}}}));
//# sourceMappingURL=bullet.release.wasm-e702f478.js.map
