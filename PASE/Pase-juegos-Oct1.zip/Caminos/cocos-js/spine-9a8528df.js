System.register([],(function(e){"use strict";return{execute:function(){e("default","assets/spine-59f406dc.wasm")}}}));
//# sourceMappingURL=spine-9a8528df.js.map
