System.register([],(function(e){"use strict";return{execute:function(){e("default","assets/meshopt_decoder.wasm-12c0a404.wasm")}}}));
//# sourceMappingURL=meshopt_decoder.wasm-43855155.js.map
