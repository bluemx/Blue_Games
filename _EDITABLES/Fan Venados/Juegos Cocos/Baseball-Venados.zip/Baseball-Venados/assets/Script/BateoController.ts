import { _decorator, CCFloat, Component, Input, input, EventKeyboard, SystemEvent, KeyCode, Node, Sprite, SpriteFrame, tween, Vec3, color, Color, randomRangeInt, CCBoolean, CCInteger, Prefab, instantiate, Label } from 'cc';
import { ManagerLabel } from './ManagerLabel';
import { Score } from './Score';
import { ButtonMessage } from './ButtonMessage';
const { ccclass, property } = _decorator;

@ccclass('BateoController')
export class BateoController extends Component {
    @property([Prefab])
    public PrefabConfetti : Prefab[] = [];
    @property(Node)
    public Particulas : Node = null;
    @property(Node)
    public ball : Node = null;
    @property(Node)
    public bat : Node = null;
    @property(Node)
    public puntero : Node = null;
    @property([SpriteFrame])
    public imagenespuntero : SpriteFrame[] = [];
    @property(Vec3)
    public PosicionInicial : Vec3 = new Vec3(0,0,0);
    @property(Vec3)
    public PosicionFinal : Vec3 = new Vec3(0,-300,0);
    @property(Vec3)
    public posicionBateo : Vec3 = new Vec3(0, 500, 0);

    @property (CCFloat)
    public tiempoLanzamiento : number = 2.8;

    @property(CCFloat)
    public empiezabateo : number = 1.2;
    @property(CCFloat)
    public Homerun : number = 1.3;
    @property(CCFloat)
    public terminabateo : number = 1.5;
    private TiempoInicial: number = 0; // Tiempo en el que la pelota fue lanzada
    private mantenerdedo: boolean = false;
    private  bateo: number  = 0;
    @property(CCFloat)
    public elapsedTime : number = 0;
    
    @property(CCBoolean)
    private lanzamiento : boolean = false;
    private golpeExitoso : boolean = false;
    @property(CCBoolean)
    public Gameover : boolean = false;
    @property(CCInteger)
    private Striks : number = 0;
    @property(Node)
    public GameOver : Node = null;

    @property(Node)
    public fuera: Node = null;
    @property(Node)
    public mensaje : Node = null;
     
    @property([Node])
    public Posiciones : Node[] =[];
    protected onLoad(): void {
        //input.on(Input.EventType.KEY_DOWN, this.onkeyDown, this);
        //this.node.on(Node.EventType.TOUCH_START, this.onTouch, this);
        this.node.on(Node.EventType.TOUCH_START, this.onTouch, this)
        this.node.on(Node.EventType.TOUCH_END, this.onTouchCancel, this)
        this.ball.setPosition(this.PosicionInicial);
        this.ball.scale = new Vec3(0.3,.3,.3);
        this.puntero.getComponent(Sprite).color= new Color( 255,255,255,255);
        this.scheduleOnce(function(){
            this.launchBall();
        },3)

        //this.Striks = 0;
        this.GameOver.active= false;
        this.fuera.active=false;
    }
    start() {
        
        
    }
    resetea(){
        this.golpeExitoso = false;
        this.ball.setSiblingIndex(1);
        this.lanzamiento = false;
        this.puntero.setPosition(this.Posiciones[0].position)
        this.ball.setPosition(this.PosicionInicial);
        this.ball.scale = new Vec3(0.3,.3,.3);
        this.scheduleOnce(function(){
            this.launchBall();
        },3)
    }
    sumaStricks(){
        this.Striks +=1;
                if(this.Striks >= 3){
                    this.Gameover = true;
                    this.scheduleOnce(function(){
                        this.fuera.active = true;
                    },2);
                    
                }
    }
    lanzamientoBajo() {
        this.lanzamiento= true;
        
        this.empiezabateo = 1;
        this.Homerun = 1.1;
        this.terminabateo = 1.2;
        
        // Movimiento hacia adelante (de inicio a fin)
        tween(this.ball)
        .to(this.tiempoLanzamiento, { angle:360*2,position: this.PosicionFinal, scale: new Vec3(1.5, 1.5, 1.5)})
        .call(() =>{
            this.lanzamiento=false;
            if(!this.golpeExitoso){
                //console.log('¡Fallaste!');
                this.getComponent(ManagerLabel).ActiveStrike();
                this.sumaStricks();
                this.scheduleOnce(function(){
                    this.resetea();
                    this.getComponent(ManagerLabel).ReseteaAnim();
                },5)
            
            }
            else{
                tween(this.ball)
                .stop();
            }
        })
        
        .start();
        
        
    }
    launchBall() {
        if(this.Gameover){
            this.GameOver.active = true;
            let s =this.node.getComponent(Score).score;
            let label = this.GameOver.children[3].getComponent(Label);
            if(s<1){
                
                label.string = "Vuelve a intentar..."
                label.fontSize = 40;
            }
            else{
                label.string = "Felicidades"
                label.fontSize = 70;
            }
            this.mensaje.getComponent(ButtonMessage).sendMessageToParent();
        }
        else{
            this.ball.setSiblingIndex(10);
            let tipo = randomRangeInt(0,3);
            //console.log("tipo es igual a " + tipo.toString())
            this.TiempoInicial = performance.now() / 1000; // Tiempo inicial en segundos
            
            switch(tipo){
                case 0: 
                 this.lanzamientoBajo();
                break;
                case 1: 
                this.derecha();
                break;
                case 2:
                    this.izquierda()
                break;
            }
            // Configura la pelota para que se mueva de inicio a fin
            
            
        }
       
    }
    izquierda(){
        this.lanzamiento = true;
        this.empiezabateo = 1.3;
        this.Homerun = 1.4;
        this.terminabateo = 1.6;
        let midPoint = new Vec3((-this.PosicionInicial.x + -this.PosicionFinal.x) / 2, 150, 0 );
             tween(this.ball)
            .to(this.tiempoLanzamiento/3, { position: midPoint, scale: new Vec3(1, 1, 1) , angle : 180})
            .to(this.tiempoLanzamiento/2, { position: this.PosicionFinal, scale: new Vec3(1.5,1.5,1.5), angle : 359})
            .call(() =>{
                this.lanzamiento=false;
                if(!this.golpeExitoso){
                   // console.log('¡Fallaste!');
                   
                    this.getComponent(ManagerLabel).ActiveStrike();
                    this.sumaStricks();
                    this.scheduleOnce(function(){
                        this.resetea();
                        this.getComponent(ManagerLabel).ReseteaAnim();
                    },5)
                
                }
                else{
                    tween(this.ball)
                    .stop();
                }
            })
            .start();
            this.puntero.setPosition(this.Posiciones[2].position)
           
    }
    derecha(){
        this.lanzamiento = true;
        this.empiezabateo = 1.3;
        this.Homerun = 1.4;
        this.terminabateo = 1.6;
        let midPoint2 = new Vec3((this.PosicionInicial.x + this.PosicionFinal.x) / 2, 150, 0 );
        tween(this.ball)
        .to(this.tiempoLanzamiento/3, { position: midPoint2, scale: new Vec3(1, 1, 1) , angle : 180})
        .to(this.tiempoLanzamiento/2, { position: this.PosicionFinal, scale: new Vec3(1.5,1.5,1.5), angle : 359})
        .call(() =>{
            this.lanzamiento=false;
            if(!this.golpeExitoso){
                //console.log('¡Fallaste!');
                this.getComponent(ManagerLabel).ActiveStrike();
                this.sumaStricks();
                this.scheduleOnce(function(){
                    this.resetea();
                    this.getComponent(ManagerLabel).ReseteaAnim();
                },5)
            
            }
            else{
                tween(this.ball)
                .stop();
            }
            
        })
        .start();
        
        this.puntero.setPosition(this.Posiciones[1].position)
       
    }
    onTouch(EventType:Touch) {
        this.mantenerdedo = true;
        this.puntero.getComponent(Sprite).color= new Color( 41,165,56,255);
        this.bateo = performance.now() / 1000; // Marca el tiempo del inicio del toque

       // console.log('Preparando el swing...');
        tween(this.bat)
        .to(0.2, { angle: -45}) // El bate se mueve
        .start();
       
    }
    onTouchCancel(EventType:Touch){
        this.mantenerdedo = false;
        const tiempoReaccion = performance.now() / 1000 - this.TiempoInicial;
        //console.log('Ejecutando el swing...');
        tween(this.bat)
        .to(0.2, { angle: 0 }) // El bate regresa al punto de golpe
        .start();
        

        if (tiempoReaccion >= this.empiezabateo && tiempoReaccion <= this.terminabateo) {
            
            //console.log('¡Golpe exitoso!');
            this.golpeExitoso=true;
           
            tween(this.ball)
            .to(1,{position: this.posicionBateo, scale: new Vec3(.2,.2,.2)})
            .call(() => {
                if (!this.mantenerdedo) {
                    //console.log('Home!.');
                    const node1 = instantiate(this.PrefabConfetti[0]);
                    node1.setParent(this.Particulas);
                    const node2 = instantiate(this.PrefabConfetti[1]);
                    node2.setParent(this.Particulas);
                    this.borra( node1, node2);
                    this.getComponent(ManagerLabel).ActiveHomeRun();
                    this.getComponent(Score).LabelScore();
                    this.scheduleOnce(function(){
                        this.resetea();
                        this.getComponent(ManagerLabel).ReseteaAnim();
                    },3)
                }
            })
            .start();
            // Aquí puedes agregar una animación para el golpe exitoso
        } else {
            //falla
            
            // Aquí puedes agregar una animación de fallo

            
        }
        this.puntero.getComponent(Sprite).color= new Color( 255,255,255,255);
    }
    onkeyDown(event: EventKeyboard){
        if (event.keyCode == KeyCode.KEY_R) {
            //console.log('¡Presionaste la tecla R!');
            this.resetea();
        }
    }
  
    borra( Node1 : Node , node2 : Node){
        this.scheduleOnce(function(){
            Node1.destroy();
            node2.destroy();
        },5)
    }
    update(deltaTime: number) {
        const currentTime = performance.now() / 1000;
        const tiempoReaccion = currentTime - this.TiempoInicial;
        
        if(tiempoReaccion >= this.empiezabateo && tiempoReaccion <= this.terminabateo){
            //console.log("BA_TEAAA");
            this.puntero.getComponent(Sprite).spriteFrame = this.imagenespuntero[1];
        }
        else{
            this.puntero.getComponent(Sprite).spriteFrame = this.imagenespuntero[0];
 
        }
        
    }
}


