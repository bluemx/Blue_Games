import { _decorator, Component, Button } from 'cc';
import { Score } from './Score';

const { ccclass, property } = _decorator;

@ccclass('ButtonMessage')
export class ButtonMessage extends Component {
    @property(Score)
    public manScore : Score = null;


    sendMessageToParent() {
        window.parent?.postMessage({
            score: this.manScore.score
        }, '*');
    }
    sendMessageToExit() {
        window.parent?.postMessage({
            state: 'exit'
        }, '*');
    }
    sendMessageToRestart() {
        window.parent?.postMessage({
            state: 'reset'
        }, '*');
    }
     sendMessageToStart() {
        window.parent?.postMessage({
            state: 'start'
        }, '*');
    }
}