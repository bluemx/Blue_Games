import { _decorator, Component, Label, Node } from 'cc';
import { BateoController } from './BateoController';
const { ccclass, property } = _decorator;

@ccclass('Score') 
export class Score extends Component {

    public score : number = 0;
    @property(Label)
    public ScoreLabel: Label = null;
    @property(Label)
    public ScoreFinal : Label = null;
    LabelScore(){
        this.score ++;
        if(this.score <= 0){
            this.score = 0;
        }
        else if ( this.score >= 1000){
            this.score = 1000;
            this.getComponent(BateoController).Gameover = true;
        }
        this.ScoreLabel.string = this.score.toString();
        this.ScoreFinal.string = this.score.toString();
    }
    protected onLoad(): void {
        //this.score = 1000;
    }
    start() {

    }

    update(deltaTime: number) {
        
    }
}


