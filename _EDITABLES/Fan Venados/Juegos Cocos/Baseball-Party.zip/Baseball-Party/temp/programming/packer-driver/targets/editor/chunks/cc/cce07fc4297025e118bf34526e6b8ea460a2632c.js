System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Collider2D, Component, Node, RigidBody2D, Vec2, Contact2DType, find, Score, BateoController, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _crd, ccclass, property, ObjetoController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfScore(extras) {
    _reporterNs.report("Score", "./Score", _context.meta, extras);
  }

  function _reportPossibleCrUseOfBateoController(extras) {
    _reporterNs.report("BateoController", "./BateoController", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Collider2D = _cc.Collider2D;
      Component = _cc.Component;
      Node = _cc.Node;
      RigidBody2D = _cc.RigidBody2D;
      Vec2 = _cc.Vec2;
      Contact2DType = _cc.Contact2DType;
      find = _cc.find;
    }, function (_unresolved_2) {
      Score = _unresolved_2.Score;
    }, function (_unresolved_3) {
      BateoController = _unresolved_3.BateoController;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "b4ed1sN9dVJZ4ZsqMEsgu5u", "ObjetoController", undefined);

      __checkObsolete__(['_decorator', 'Collider2D', 'Component', 'Node', 'RigidBody2D', 'Vec2', 'Contact2DType', 'IPhysics2DContact', 'BoxCollider2D', 'find']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("ObjetoController", ObjetoController = (_dec = ccclass('ObjetoController'), _dec2 = property(_crd && Score === void 0 ? (_reportPossibleCrUseOfScore({
        error: Error()
      }), Score) : Score), _dec3 = property(_crd && BateoController === void 0 ? (_reportPossibleCrUseOfBateoController({
        error: Error()
      }), BateoController) : BateoController), _dec(_class = (_class2 = class ObjetoController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "MS", _descriptor, this);

          _initializerDefineProperty(this, "bateo", _descriptor2, this);
        }

        onLoad() {
          const colision = this.node.getComponent(Collider2D);

          if (colision) {
            this.node.on(Node.EventType.TOUCH_START, this.onTouch, this);
            this.node.on(Node.EventType.TOUCH_END, this.onTouchCancel, this);
            colision.on(Contact2DType.BEGIN_CONTACT, this.trigger, this);
            colision.on(Contact2DType.END_CONTACT, this.exitTrigger, this);
          } //this.node.on(Node.EventType.TOUCH_START, this.onTouch, this);

        }

        trigger(selfCollider, otherCollider, contact) {
          console.log("contacto " + otherCollider.tag);

          if (otherCollider.tag == 5 && selfCollider.tag == 0) {
            this.bateo.sumaStricks();
          }

          if (otherCollider.tag == 5 && selfCollider.tag == 2) {
            this.MS.labelScoreBasura();
          }
        }

        exitTrigger(selfCollider, otherCollider, contact) {
          console.log("sali de" + otherCollider.tag);

          if (otherCollider.tag == 20) {
            this.scheduleOnce(function () {
              this.destroyNode();
            }, .2);
          }
        }

        onTouch(EventType) {
          const collider = this.node.getComponent(Collider2D);
          console.log("lanzar objeto " + collider.tag);

          switch (collider.tag) {
            case 0:
              this.MS.LabelScore();
              this.node.getComponent(RigidBody2D).applyLinearImpulseToCenter(new Vec2(0, 120), true);
              break;

            case 2:
              this.MS.LabelScoreNegativo();
              this.node.getComponent(Collider2D).enabled = false;
              this.destroyNode();
              break;
          }
        }

        onTouchCancel(EventType) {}

        destroyNode() {
          this.node.destroy();
        }

        start() {
          this.MS = find("Canvas/ManagerScore").getComponent(_crd && Score === void 0 ? (_reportPossibleCrUseOfScore({
            error: Error()
          }), Score) : Score);
          this.bateo = find("Canvas/fondo/maquina").getComponent(_crd && BateoController === void 0 ? (_reportPossibleCrUseOfBateoController({
            error: Error()
          }), BateoController) : BateoController);
        }

        update(deltaTime) {}

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "MS", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "bateo", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=cce07fc4297025e118bf34526e6b8ea460a2632c.js.map