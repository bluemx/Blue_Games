System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, CCFloat, Component, Node, tween, Vec3, randomRangeInt, CCBoolean, CCInteger, Prefab, instantiate, RigidBody2D, Vec2, Label, Score, ButtonMessage, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _dec13, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _crd, ccclass, property, BateoController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfScore(extras) {
    _reporterNs.report("Score", "./Score", _context.meta, extras);
  }

  function _reportPossibleCrUseOfButtonMessage(extras) {
    _reporterNs.report("ButtonMessage", "./ButtonMessage", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      CCFloat = _cc.CCFloat;
      Component = _cc.Component;
      Node = _cc.Node;
      tween = _cc.tween;
      Vec3 = _cc.Vec3;
      randomRangeInt = _cc.randomRangeInt;
      CCBoolean = _cc.CCBoolean;
      CCInteger = _cc.CCInteger;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
      RigidBody2D = _cc.RigidBody2D;
      Vec2 = _cc.Vec2;
      Label = _cc.Label;
    }, function (_unresolved_2) {
      Score = _unresolved_2.Score;
    }, function (_unresolved_3) {
      ButtonMessage = _unresolved_3.ButtonMessage;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "74b8aupSq9HaZTvFGZHfKEC", "BateoController", undefined);

      __checkObsolete__(['_decorator', 'CCFloat', 'Component', 'Node', 'Sprite', 'SpriteFrame', 'tween', 'Vec3', 'color', 'Color', 'randomRangeInt', 'CCBoolean', 'CCInteger', 'Prefab', 'instantiate', 'RigidBody2D', 'Vec2', 'Label']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("BateoController", BateoController = (_dec = ccclass('BateoController'), _dec2 = property([Prefab]), _dec3 = property(Node), _dec4 = property([Prefab]), _dec5 = property(Node), _dec6 = property(Node), _dec7 = property(Vec3), _dec8 = property(Vec3), _dec9 = property(CCBoolean), _dec10 = property(CCInteger), _dec11 = property(Node), _dec12 = property(CCFloat), _dec13 = property([Node]), _dec(_class = (_class2 = class BateoController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "PrefabConfetti", _descriptor, this);

          _initializerDefineProperty(this, "Particulas", _descriptor2, this);

          _initializerDefineProperty(this, "objetos", _descriptor3, this);

          _initializerDefineProperty(this, "ball", _descriptor4, this);

          _initializerDefineProperty(this, "mensaje", _descriptor5, this);

          _initializerDefineProperty(this, "PosicionInicial", _descriptor6, this);

          _initializerDefineProperty(this, "PosicionFinal", _descriptor7, this);

          this.golpeExitoso = false;

          _initializerDefineProperty(this, "Gameover", _descriptor8, this);

          _initializerDefineProperty(this, "Striks", _descriptor9, this);

          _initializerDefineProperty(this, "GameOver", _descriptor10, this);

          _initializerDefineProperty(this, "speed", _descriptor11, this);

          this.puedeLanzar = false;

          _initializerDefineProperty(this, "vidas", _descriptor12, this);
        }

        onLoad() {
          this.scheduleOnce(function () {
            this.puedeLanzar = true;
          }, 3); //this.Striks = 0;

          this.GameOver.active = false;
        }

        start() {
          this.schedule(function () {
            this.speed -= .02;

            if (this.speed <= .2) {
              this.speed = .2;
            }
          }, 5);
        }

        resetea() {
          this.golpeExitoso = false;
          this.scheduleOnce(function () {
            this.launchBall();
          }, 3);
        }

        sumaStricks() {
          this.vidas[this.Striks].active = false;
          this.Striks += 1;

          if (this.Striks >= 3) {
            this.Gameover = true;
          }
        }

        lanzamientoBajo() {
          // Movimiento hacia adelante (de inicio a fin)
          const visual = this.ball.children[0];
          visual.setScale(new Vec3(.3, .3, .3));
          tween(visual).to(2, {
            scale: new Vec3(1.5, 1.5, 1.5)
          }).start();
        }

        launchBall() {
          let posx = randomRangeInt(-200, 200);
          this.PosicionFinal = new Vec3(posx, this.PosicionFinal.y, this.PosicionFinal.z);
          let prefabrandom = randomRangeInt(0, 11);
          const ball = instantiate(this.objetos[prefabrandom]);
          this.ball = ball;
          this.ball.setPosition(this.PosicionInicial);
          this.puedeLanzar = true;
          this.ball.setParent(this.node);

          if (this.Gameover) {
            this.mensaje.getComponent(_crd && ButtonMessage === void 0 ? (_reportPossibleCrUseOfButtonMessage({
              error: Error()
            }), ButtonMessage) : ButtonMessage).sendMessageToParent();
            this.GameOver.active = true;
            let label = this.GameOver.children[3].getComponent(Label);
            let s = this.mensaje.getComponent(_crd && Score === void 0 ? (_reportPossibleCrUseOfScore({
              error: Error()
            }), Score) : Score).score;

            if (s < 1) {
              label.string = "Vuelve a intentar...";
              label.fontSize = 40;
            } else {
              label.string = "Felicidades";
              label.fontSize = 70;
            }

            this.node.active = false;
          } else {
            this.ball.setSiblingIndex(10);
            let tipo = randomRangeInt(0, 3);
            console.log("tipo es igual a " + tipo.toString());
            const r = randomRangeInt(0, 2);
            let rotacion = 0;

            switch (r) {
              case 0:
                rotacion = randomRangeInt(-8, -4);
                break;

              case 1:
                rotacion = randomRangeInt(5, 9);
                break;
            }

            this.ball.getComponent(RigidBody2D).angularVelocity = rotacion;

            switch (tipo) {
              case 0:
                this.lanzamientoBajo();
                break;

              case 1:
                this.derecha();
                break;

              case 2:
                this.izquierda();
                break;
            } // Configura la pelota para que se mueva de inicio a fin

          }
        }

        izquierda() {
          let x = randomRangeInt(-10, -1);
          this.ball.getComponent(RigidBody2D).applyLinearImpulseToCenter(new Vec2(x, .5), true);
          const visual = this.ball.children[0];
          visual.setScale(new Vec3(.3, .3, .3));
          tween(visual).to(1, {
            scale: new Vec3(1, 1, 1),
            angle: 180
          }).to(2, {
            scale: new Vec3(1.5, 1.5, 1.5),
            angle: 359
          }).start();
        }

        derecha() {
          let x = randomRangeInt(2, 11);
          this.ball.getComponent(RigidBody2D).applyLinearImpulseToCenter(new Vec2(x, .5), true);
          const visual = this.ball.children[0];
          visual.setScale(new Vec3(.3, .3, .3));
          tween(visual).to(1, {
            scale: new Vec3(1, 1, 1),
            angle: -180
          }).to(2, {
            scale: new Vec3(1.5, 1.5, 1.5),
            angle: -359
          }).start();
        }

        update(deltaTime) {
          if (this.puedeLanzar && !this.Gameover) {
            this.scheduleOnce(function () {
              this.launchBall();
            }, this.speed);
            this.puedeLanzar = false;
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "PrefabConfetti", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "Particulas", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "objetos", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "ball", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "mensaje", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "PosicionInicial", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return new Vec3(0, 0, 0);
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "PosicionFinal", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return new Vec3(0, -300, 0);
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "Gameover", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return false;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "Striks", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 0;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "GameOver", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "speed", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 5;
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "vidas", [_dec13], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=bfc65e481eff7d6b23263028e1e24313b6724dee.js.map