import { _decorator, Collider2D, Component, Node, RigidBody2D, Vec2, Contact2DType, IPhysics2DContact, BoxCollider2D, find } from 'cc';
import { Score } from './Score';
import { BateoController } from './BateoController';
const { ccclass, property } = _decorator;

@ccclass('ObjetoController')
export class ObjetoController extends Component {

    @property(Score)
    public MS : Score = null;
    @property(BateoController)
    public bateo : BateoController = null;
    protected onLoad(): void {
        
         const colision = this.node.getComponent(Collider2D);
        if(colision){

            
            this.node.on(Node.EventType.TOUCH_START, this.onTouch, this)
            this.node.on(Node.EventType.TOUCH_END, this.onTouchCancel, this)
            colision.on(Contact2DType.BEGIN_CONTACT, this.trigger, this);
            colision.on(Contact2DType.END_CONTACT, this.exitTrigger, this);
            
        }
                //this.node.on(Node.EventType.TOUCH_START, this.onTouch, this);
                
    }
    trigger(selfCollider : Collider2D, otherCollider: Collider2D, contact : IPhysics2DContact){
        console.log("contacto " + otherCollider.tag);
        if(otherCollider.tag==5 && selfCollider.tag == 0){
            this.bateo.sumaStricks();
        }
        if(otherCollider.tag == 5 && selfCollider.tag == 2){
            this.MS.labelScoreBasura();
        }
    }
    exitTrigger(selfCollider : Collider2D, otherCollider: Collider2D, contact : IPhysics2DContact){

        console.log("sali de" + otherCollider.tag);
        if(otherCollider.tag == 20){
            this.scheduleOnce(function(){
                this.destroyNode();
            },.2);
            

            
        }
    }
    onTouch(EventType:Touch){
       
        
        const collider = this.node.getComponent(Collider2D);
         console.log("lanzar objeto " + collider.tag);
        switch(collider.tag){
            case 0:
            this.MS.LabelScore();
            this.node.getComponent(RigidBody2D).applyLinearImpulseToCenter(new Vec2(0,120),true);
            break;
            case 2:
            this.MS.LabelScoreNegativo();
            this.node.getComponent(Collider2D).enabled=false;
            this.destroyNode();
            break;

        }
        
        
    }
    onTouchCancel(EventType:Touch){

    }
    destroyNode(){
        
        this.node.destroy();
    }
    start() {
        this.MS = find("Canvas/ManagerScore").getComponent(Score);
        this.bateo = find("Canvas/fondo/maquina").getComponent(BateoController);

    }

    update(deltaTime: number) {
        
    }
}


