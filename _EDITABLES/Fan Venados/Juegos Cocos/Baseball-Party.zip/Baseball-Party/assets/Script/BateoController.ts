import { _decorator, CCFloat, Component, Node, Sprite, SpriteFrame, tween, Vec3, color, Color, randomRangeInt, CCBoolean, CCInteger, Prefab, instantiate, RigidBody2D, Vec2, Label } from 'cc';
import { ManagerLabel } from './ManagerLabel';
import { Score } from './Score';
import { ButtonMessage } from './ButtonMessage';
const { ccclass, property } = _decorator;

@ccclass('BateoController')
export class BateoController extends Component {
    @property([Prefab])
    public PrefabConfetti : Prefab[] = [];
    @property(Node)
    public Particulas : Node = null;
    @property([Prefab])
    public objetos : Prefab[] = [];
    @property(Node)
    public ball : Node = null;
    @property(Node)
    public mensaje : Node = null;
   
    @property(Vec3)
    public PosicionInicial : Vec3 = new Vec3(0,0,0);
    @property(Vec3)
    public PosicionFinal : Vec3 = new Vec3(0,-300,0);
    
    private golpeExitoso : boolean = false;
    @property(CCBoolean)
    public Gameover : boolean = false;
    @property(CCInteger)
    private Striks : number = 0;
    @property(Node)
    public GameOver : Node = null;
   @property(CCFloat)
   private speed : number = 5;
    private puedeLanzar : boolean = false;
    @property([Node])
    public vidas : Node [] = [];
     
   
    protected onLoad(): void {
        
       
        this.scheduleOnce(function(){
            this.puedeLanzar = true;
        },3);

        //this.Striks = 0;
        this.GameOver.active= false;
        
    }
    start() {
        this.schedule(function(){
                 this.speed -= .02;
                if(this.speed <= .2){
                    this.speed = .2;
                }
            },5);
        
    }
    resetea(){
        this.golpeExitoso = false;
        this.scheduleOnce(function(){
            this.launchBall();
        },3)
    }
    sumaStricks(){
        this.vidas[this.Striks].active = false;
        this.Striks +=1;
                if(this.Striks >= 3){
                    this.Gameover = true;
                    
                    
                }
    }
    lanzamientoBajo() {
        
        // Movimiento hacia adelante (de inicio a fin)
        const visual = this.ball.children[0];
            visual.setScale(new Vec3(.3,.3,.3));

             tween(visual)
        .to(2, { scale: new Vec3(1.5, 1.5, 1.5)})
        .start();
        
        
    }
    launchBall() {
        let posx = randomRangeInt(-200,200);
        this.PosicionFinal = new Vec3(posx, this.PosicionFinal.y, this.PosicionFinal.z);
        let prefabrandom = randomRangeInt(0,11);
        const ball = instantiate(this.objetos[prefabrandom]);
        this.ball = ball;
        this.ball.setPosition(this.PosicionInicial);
        this.puedeLanzar = true;
        this.ball.setParent(this.node);
       
        if(this.Gameover){
            this.mensaje.getComponent(ButtonMessage).sendMessageToParent();
            this.GameOver.active = true;
            let label = this.GameOver.children[3].getComponent(Label);
            let s = this.mensaje.getComponent(Score).score;
            if(s<1){
                label.string = "Vuelve a intentar..."
                label.fontSize = 40;
            }
            else{
                label.string = "Felicidades"
                label.fontSize = 70;
            }
            this.node.active=false;
        }
        else{
            this.ball.setSiblingIndex(10);
            let tipo = randomRangeInt(0,3);
            console.log("tipo es igual a " + tipo.toString())
             const r = randomRangeInt(0,2);
             let rotacion = 0;
             switch(r){
                case 0:
                    rotacion = randomRangeInt(-8,-4);
                break;
                case 1:
                    rotacion = randomRangeInt(5,9);
                break;

            }
            this.ball.getComponent(RigidBody2D).angularVelocity = rotacion;
            switch(tipo){
                case 0: 
                 this.lanzamientoBajo();
                break;
                case 1: 
                this.derecha();
                break;
                case 2:
                    this.izquierda()
                break;
            }
            // Configura la pelota para que se mueva de inicio a fin
            
            
        }
       
    }
    izquierda(){
         
      
        let x = randomRangeInt(-10,-1);
        this.ball.getComponent(RigidBody2D).applyLinearImpulseToCenter(new Vec2(x,.5),true);
        
            const visual = this.ball.children[0];
            visual.setScale(new Vec3(.3,.3,.3));
             tween(visual)
            .to(1, { scale: new Vec3(1, 1, 1) , angle : 180})
            .to(2, { scale: new Vec3(1.5,1.5,1.5), angle : 359})
            .start();
           
    }
    derecha(){
       
        let x = randomRangeInt(2,11);

        this.ball.getComponent(RigidBody2D).applyLinearImpulseToCenter(new Vec2(x,.5),true);
        const visual = this.ball.children[0];
            visual.setScale(new Vec3(.3,.3,.3));

         tween(visual)
        .to(1, { scale: new Vec3(1, 1, 1) , angle : -180 })
        .to(2, { scale: new Vec3(1.5,1.5,1.5), angle : - 359})
        .start();
       
    }
    update(deltaTime: number) {
        if(this.puedeLanzar && !this.Gameover){
            this.scheduleOnce(function(){
            this.launchBall();
            
        },this.speed)
        this.puedeLanzar = false;
        }
    }
}


