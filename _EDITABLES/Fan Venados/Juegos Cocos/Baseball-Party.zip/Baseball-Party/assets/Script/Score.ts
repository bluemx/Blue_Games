import { _decorator, Component, Label, Node } from 'cc';
import { BateoController } from './BateoController';

const { ccclass, property } = _decorator;

@ccclass('Score') 
export class Score extends Component {

    @property(BateoController)
    public bateo : BateoController = null;
    public score : number = 0;
    @property(Label)
    public ScoreLabel: Label = null;
    @property(Label)
    public ScoreFinal : Label = null;
    private index : number = 0;
    LabelScore(){
        this.score ++;
        console.log("suma uno");
         this.ScoreLabel.string = this.score.toString();
        this.ScoreFinal.string = this.score.toString();
        if(this.score <= 0){
            this.score = 0;
        }
        else if ( this.score >= 1000){
            this.score = 1000;
           //terimina el juego
        }
       
    }
    labelScoreBasura(){
        this.index ++;
        if(this.index >= 20){
            this.score++;
            this.ScoreLabel.string = this.score.toString();
            this.ScoreFinal.string = this.score.toString();
            this.index = 0;
        }
    }
    LabelScoreNegativo(){
         this.score --;
         
        if(this.score <= 0){
            this.score = 0;
            //termina juego;
            this.bateo.Gameover = true;
        }
        this.ScoreLabel.string = this.score.toString();
        this.ScoreFinal.string = this.score.toString();
    }
    protected onLoad(): void {
        //this.score = 1000;
    }
    start() {

    }

    update(deltaTime: number) {
        
    }
}


