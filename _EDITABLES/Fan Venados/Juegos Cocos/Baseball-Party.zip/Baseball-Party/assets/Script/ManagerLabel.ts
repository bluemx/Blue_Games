import { _decorator, animation, Component, Node, Animation } from 'cc';
import { Score } from './Score';
const { ccclass, property } = _decorator;


@ccclass('ManagerLabel')
export class ManagerLabel extends Component {
    @property(Node)
    public Strike : Node = null;
    @property(Node)
    public HomeRun : Node = null;
    @property(Node)
    public Nice : Node = null;
    protected onLoad(): void {
        this.Strike.active = false;
        this.HomeRun.active = false;
        this.Nice.active = false;
    }
    start() {

    }
    ActiveHomeRun(){
        this.HomeRun.active = true;
        this.HomeRun.getComponent(Animation).play();
    }
    ActiveStrike(){
        this.Strike.active = true;
        this.Strike.getComponent(Animation).play();
    }
    ActivaNice(){
        this.Nice.active = true;
        this.Nice.getComponent(Animation).play();
    }
    ReseteaAnim(){
        this.Strike.active = false;
        this.HomeRun.active = false;
        this.Nice.active = false;
    }
    update(deltaTime: number) {
        
    }
}


