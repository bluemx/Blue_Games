import { _decorator, Camera, CCBoolean, CCInteger, Component, math, Node, postProcess, Vec3 } from 'cc';
import { Tiro_Pelota } from './Tiro-Pelota';
import { UITransform } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('ZoomOut')
export class ZoomOut extends Component {

    @property(Node)
    public piso: Node = null;

    @property
    public bottomPadding: number = 0;

    @property(CCInteger)
    public limiteCamara : number  = 0;

    @property(CCInteger)
    public InfCamara : number = 0;

    @property(Camera)
    public CameraZoom : Camera = null;

    @property(CCBoolean)
    public empieza : boolean = false;

    @property(Node)
    public pelota : Node = null;

    @property(Node)
    public porteria : Node = null;
    @property(Node)
    public PosCam : Node = null;

    @property(Tiro_Pelota)
    private tira : Tiro_Pelota = null;

    // --- NUEVOS AJUSTES PARA UN SEGUIMIENTO SUAVE ---
    @property(Vec3)
    public offset: Vec3 = new Vec3(0, 50, 0);        // Desplazamiento vertical

    @property
    public damping: number = 10;                     // Suavizado (1/seg). 8-12 es buen rango

    @property(CCInteger)
    public deadZone: number = 6;                     // Radio (pixeles) para ignorar micro-movimientos

    @property(CCInteger)
    public maxFollowSpeed: number = 2000;            // Límite de velocidad (pixeles/seg) para evitar “tirones”

    private _tmp: Vec3 = new Vec3();
    @property(CCBoolean)
    public regresa : boolean = false;
    @property(CCBoolean)
    private inicio : boolean = false;
    private comienza : boolean = false;
    public zoom :boolean = false;
    protected onLoad(): void {
       
    }
    start() {

        this.CamInicio();
    }

    CamInicio(){
        //this.CameraZoom.orthoHeight = this.limiteCamara;
        this.inicio = true;
        this.empieza = true;
        this.regresa = false;
        this.scheduleOnce(function(){
            this.inicio = false;
            this.empieza = false;
            this.regresa = true
           
            
        },5);
    }
    private followTarget( targetN: Node, dt: number) {
        if (!targetN) return;

        // Usar posiciones en WORLD para evitar diferencias por padres distintos
        const target = new Vec3();
        const current = new Vec3();
        targetN.getWorldPosition(target);
        this.node.getWorldPosition(current);

        // Aplicar offset deseado (p.ej. mirar un poco por encima)
        Vec3.add(target, target, this.offset);

        // Vector hacia el objetivo
        Vec3.subtract(this._tmp, target, current);
        const dist = this._tmp.length();

        // Zona muerta: si estamos suficientemente cerca, no muevas la cámara
        if (dist < this.deadZone) return;

        // Exponential smoothing independiente del framerate:
        // t = 1 - e^(-lambda * dt)
        const t = 1 - Math.exp(-this.damping * dt);

        // Paso deseado suavizado
        const step = new Vec3(
            this._tmp.x * t,
            this._tmp.y * t,
            0
        );

        // Clamp por velocidad máxima para evitar saltos bruscos
        const maxStep = this.maxFollowSpeed * dt;
        const stepLen = step.length();
        if (stepLen > maxStep) {
            step.multiplyScalar(maxStep / stepLen);
        }

        // Nueva posición en world (mantén Z actual)
        const desired = new Vec3(current.x + step.x, current.y + step.y, current.z);
        const groundTopY = this.getGroundTopY();
        const minCamCenterY = groundTopY + this.CameraZoom.orthoHeight + this.bottomPadding;
        desired.y = Math.max(desired.y, minCamCenterY);
        this.node.setWorldPosition(desired);
    }
    private getGroundTopY(): number {
        if (!this.piso) return -Infinity;
        const ui = this.piso.getComponent(UITransform);
        if (!ui) return -Infinity;
        const wp = this.piso.worldPosition;
        const sy = this.piso.worldScale.y;
        // top = worldY + (1 - anchorY) * alto * escala
        return wp.y;
    }
    private zoomOut(deltaTime : number){
        this.CameraZoom.orthoHeight = math.lerp(this.CameraZoom.orthoHeight, this.limiteCamara, 0.5 * deltaTime);
    }

    private zoomIn(deltaTime : number){
        this.CameraZoom.orthoHeight = math.lerp(this.CameraZoom.orthoHeight, this.InfCamara, 0.5 * deltaTime);
    }

    update(deltaTime: number) {
        if (this.empieza && !this.regresa) {
            this.zoomOut(deltaTime);
            this.followTarget(this.porteria,deltaTime);

        } else if (!this.empieza && this.regresa) {
            this.followTarget(this.pelota,deltaTime);
            //console.log("siguiendo pelota");
             this.zoomIn(deltaTime);
            //this.zoomIn(deltaTime);
        }
       
    }

    // Seguir a la pelota DESPUÉS de que todo se movió este frame -> menos jitter
    lateUpdate(deltaTime: number) {
       /* if(this.inicio){
            this.followTarget(this.porteria,deltaTime);

        }
        else if (!this.inicio && this.tira.puedetocar){
            this.followTarget(this.PosCam,deltaTime);
            this.zoomIn(deltaTime)

        }*/
        if (this.tira && this.tira.siguePelota) {
            this.followTarget(this.pelota,deltaTime);
            this.zoomOut(deltaTime);
            
        }
    }
}
