import { _decorator, Component, Node, Collider2D, IPhysics2DContact,Contact2DType, RigidBody2D, Vec2, Sprite, animation, Animation, UITransform } from 'cc';
import { ManagerScore } from './ManagerScore';
const { ccclass, property } = _decorator;

@ccclass('Deteccion')
export class Deteccion extends Component {
    @property(ManagerScore)
    public MScore : ManagerScore = null;
    private intentos : number = 0;
    @property(Animation)
    public animacion : Animation = null;
    @property(Node)
    public padre : Node = null;
    protected onLoad(): void {
        const colision = this.node.getComponent(Collider2D);
        if(colision){

            colision.on(Contact2DType.BEGIN_CONTACT, this.trigger, this);
            colision.on(Contact2DType.END_CONTACT, this.exitTrigger, this);

        }
    }
    start() {
        this.padre = this.node.parent;
    }
    trigger(selfCollider : Collider2D, otherCollider: Collider2D, contact : IPhysics2DContact){

        //console.log("el tag es " + otherCollider.tag);
        const tag = otherCollider.tag;
        
        switch(tag){
            case -1:
                this.intentos ++;
                this.node.getComponent(Collider2D).enabled = false;
                if(this.intentos < 3){
                    this.scheduleOnce(function(){
                    this.MScore.Reinicia();
                this.node.getComponent(Collider2D).enabled = true;
                },.4);
                }
                
                break;
            case 1:
                // estrellas suma puntos...
                
                this.animacion = otherCollider.node.getComponent(Animation);
                this.animacion.play("estrella-punto");

                this.MScore.ActualizarScore(1);
                otherCollider.enabled = false;
                
                this.scheduleOnce(function(){
                    otherCollider.node.getComponent(Sprite).enabled = false;
                    otherCollider.node.destroy();
                },.4);
                break;
            case 2:
                // enemigos baja puntos o termina el juego si no tienes puntos...
                break;
            case 3:
                // gol pasas de nivel..
                this.intentos = 0;
                this.node.setParent(otherCollider.node);
                this.node.setSiblingIndex(1);
                
                this.scheduleOnce(function(){
                    this.node.getComponent(RigidBody2D).linearVelocity = new Vec2(1,1);
                    this.node.getComponent(RigidBody2D).angularVelocity = 0;
                },.1);
                this.scheduleOnce(function(){
                this.node.setParent(this.padre);
                this.node.setSiblingIndex(3);


                },5);
                this.MScore.ActualizarScore(5);
                this.MScore.pasaNivel();
                break;
        }
    }
    exitTrigger(elfCollider : Collider2D, otherCollider: Collider2D, contact : IPhysics2DContact){
        console.log("salí de " + otherCollider.tag);
        if(otherCollider.tag == 20){
            //this.MScore.Over();
            
            this.scheduleOnce(function(){
                    this.MScore.Reinicia();
                },1.5);
        }
    }
    update(deltaTime: number) {
        if(this.intentos >= 3 && !this.MScore.gameOve){
            this.MScore.Over();
        }
    }
}


