import { _decorator, Component, Button } from 'cc';
import { ManagerScore } from './ManagerScore';

const { ccclass, property } = _decorator;

@ccclass('ButtonMessage')
export class ButtonMessage extends Component {
    @property(ManagerScore)
    public manScore : ManagerScore = null;


    sendMessageToParent() {
        window.parent?.postMessage({
            score: this.manScore.score
        }, '*');
    }
    sendMessageToExit() {
        window.parent?.postMessage({
            state: 'exit'
        }, '*');
    }
    sendMessageToRestart() {
        window.parent?.postMessage({
            state: 'reset'
        }, '*');
    }
    sendMessageToStart() {
        window.parent?.postMessage({
            state: 'start'
        }, '*');
    }
}