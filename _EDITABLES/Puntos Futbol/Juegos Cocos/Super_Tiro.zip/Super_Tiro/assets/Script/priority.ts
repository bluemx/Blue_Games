import { _decorator, CCInteger, Component, Node, Sprite, UITransform } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('priority')
export class priority extends Component {
    @property(CCInteger)
    public index : number = 0;
    start() {
        const spritea = this.node;
        spritea.setSiblingIndex(this.index);

    }

    update(deltaTime: number) {
        
    }
}


