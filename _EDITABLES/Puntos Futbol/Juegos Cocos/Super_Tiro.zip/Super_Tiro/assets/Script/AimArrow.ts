// AimArrow.ts
import { _decorator, Component, Graphics, Color, Vec3, math, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('AimArrow')
export class AimArrow extends Component {
  @property(Graphics)
  public g: Graphics = null!;

  @property({ tooltip: 'Ancho de la línea de la flecha' })
  public lineWidth: number = 6;

  @property({ tooltip: 'Largo de la cabeza de flecha' })
  public headLen: number = 30;

  @property({ tooltip: 'Ancho total de la cabeza de flecha' })
  public headWidth: number = 24;

  @property({ tooltip: 'Escala mínima de la flecha (pixeles)' })
  public minLen: number = 20;

  @property({ tooltip: 'Escala máxima de la flecha (pixeles)' })
  public maxLen: number = 300;

  @property({ tooltip: 'Suavizado (1/seg) para que la longitud no brinque' })
  public dampingLen: number = 20;

  @property(Node)
  public areaTouch : Node = null;
  private _visible = false;
  private _targetLen = 0;
  private _currentLen = 0;

  onLoad() {
    if (!this.g) {
      this.g = this.getComponent(Graphics)!;
    }
    this.g.lineWidth = this.lineWidth;
    this.g.strokeColor = new Color(255, 255, 255, 255); // blanco
    this.g.fillColor = new Color(255, 255, 255, 255);
    this.hide();
  }

  public show() {
    this._visible = true;
    this.node.active = true;
  }

  public hide() {
    this._visible = false;
    this.node.active = false;
    this.g.clear();
    this._currentLen = 0;
    this._targetLen = 0;
  }

  /**
   * Dibuja/actualiza la flecha.
   * @param origin Posición mundo del inicio (la pelota).
   * @param aim Posición mundo del puntero/arrastre.
   * @param invert Si true, la flecha apunta en sentido contrario (útil para “estirar hacia atrás” como tirachinas).
   * @param dt delta time para suavizado de longitud.
   */
  public updateArrow(origin: Vec3, aim: Vec3, invert: boolean, dt: number) {
    if (!this._visible) return;

    // Ubica el nodo en el origen y oriéntalo hacia "aim"
    this.node.setWorldPosition(this.areaTouch.worldPosition);

    const dir = new Vec3(aim.x - this.areaTouch.worldPosition.x, aim.y - this.areaTouch.worldPosition.y, 0);
    if (invert) dir.multiplyScalar(-5);

    const angleRad = Math.atan2(dir.y, dir.x);
    const angleDeg = angleRad * 180 / Math.PI;

    // Rotar el nodo para que su eje +X apunte hacia "aim"
    this.node.setRotationFromEuler(0, 0, angleDeg);

    // Longitud objetivo (clamp)
    this._targetLen = math.clamp(dir.length(), this.minLen, this.maxLen);

    // Suavizado de longitud para evitar “saltitos”
    const t = 1 - Math.exp(-this.dampingLen * dt);
    this._currentLen = math.lerp(this._currentLen, this._targetLen, t);

    // Dibujo en espacio local (eje +X)
    const len = this._currentLen;
    const hl = this.headLen;
    const hw = this.headWidth * 0.5;

    this.g.clear();

    // Cuerpo de la flecha
    this.g.moveTo(0, 0);
    this.g.lineTo(Math.max(0, len - hl), 0);
    this.g.stroke();

    // Cabeza de flecha (triángulo)
    this.g.moveTo(len, 0);
    this.g.lineTo(len - hl, hw);
    this.g.lineTo(len - hl, -hw);
    this.g.close();
    this.g.fill();
  }
}
