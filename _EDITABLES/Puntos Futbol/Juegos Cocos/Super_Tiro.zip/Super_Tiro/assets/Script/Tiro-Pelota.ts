import { _decorator, Component, EventTouch, Node, Vec3, RigidBody2D, NodeEventType, CCInteger, Vec2, Camera, math, CCBoolean, Quat, Sprite, Color } from 'cc';
import { ZoomOut } from './ZoomOut';
import { AimArrow } from './AimArrow';

const { ccclass, property } = _decorator;

@ccclass('Tiro_Pelota')
export class Tiro_Pelota extends Component {
    private tocando: boolean = false;

    @property(CCInteger)
    private maxStretch: number = 200;     // radio máx de estiramiento (unidades de mundo)

    @property(CCInteger)
    private power: number = 8;            // multiplicador de potencia del disparo

    @property(Camera)
    private Camara2D: Camera = null!;

    @property(Vec3)
    private arrastraVec: Vec3 = new Vec3();   // POSICIÓN DE ARRASTRE EN MUNDO

    @property(Vec3)
    private puntoinicial: Vec3 = new Vec3();  // POSICIÓN BASE (centro resortera)

    @property(Node)
    public areaTouch : Node = null;

    public puedetocar : boolean = true;
    private regresa: boolean = false;
    private _tmp = new Vec3();
    public lanza: boolean = false;
    public siguePelota : boolean = false;
    @property(CCBoolean)
    public aimInvert : boolean = true;
    @property(RigidBody2D)
    private rb: RigidBody2D = null!;
    @property(ZoomOut)
    public camara : ZoomOut = null;
    @property(AimArrow)
    public Arrow : AimArrow = null;
   

    protected onLoad(): void {
        this.node.on(NodeEventType.TOUCH_START, this.Touch, this);
        this.node.on(NodeEventType.TOUCH_MOVE, this.Move, this);
        this.node.on(NodeEventType.TOUCH_END, this.Cancel, this);
        this.node.on(NodeEventType.TOUCH_CANCEL, this.Cancel, this);
    }
    protected start(): void {
         this.areaTouch.getComponent(Sprite).color = new Color(200,200,200,150);
        this.node.setPosition(new Vec3(-150,0,0));
        this.node.getComponent(Sprite).color = new Color(200,200,200,150);
        this.scheduleOnce(function(){
            this.areaTouch.getComponent(Sprite).color = new Color(255,255,255,255);
            this.node.getComponent(Sprite).color = new Color(255,255,255,255);

            this.puedetocar = true;
        },6)
    }
    private screenToWorldOnZ(screenX: number, screenY: number, worldZ: number, out: Vec3) {
        out.set(screenX, screenY, worldZ);
        this.Camara2D.screenToWorld(out, out); // Convierte en el plano Z indicado
        return out;
    }

    Reinicia(){
        this.areaTouch.active = true;
        this.siguePelota = false;
        
        this.areaTouch.getComponent(Sprite).color = new Color(200,200,200,150);
        this.node.setPosition(new Vec3(-150,0,0));
        this.node.getComponent(Sprite).color = new Color(200,200,200,150);
        this.rb.gravityScale = 0;
        this.rb.linearVelocity = new Vec2(0,0);
        this.rb.angularVelocity = 0;
        
        this.node.setRotation(new Quat(0,0,0,1));
        this.tocando = false;
        this.lanza = false;
        
        this.scheduleOnce(function(){
            this.areaTouch.getComponent(Sprite).color = new Color(255,255,255,255);
            this.node.getComponent(Sprite).color = new Color(255,255,255,255);

            this.puedetocar = true;
        },3)
    }
    Touch(event: EventTouch) {
        if(this.puedetocar){
            this.tocando = true;
            this.regresa = false;
            this.lanza = false;

            // Guarda la posición base (centro de la resortera / reposo de la pelota)
            this.puntoinicial.set(this.node.worldPosition);

            // “Congela” momentáneamente la fisica mientras arrastras
            this.rb.linearVelocity = new Vec2(0, 0);
            this.rb.angularVelocity = 0;
            if (this.Arrow) this.Arrow.show();
                //this.rb.awake = true;
        }
        
    }

    Move(event: EventTouch) {
        if (!this.tocando && !this.Arrow) return;

        if(this.puedetocar){
             // Origen: posición mundo de la pelota
            const origin = this.node.worldPosition;
            // 1) UI -> MUNDO
            const loc = event.getUILocation();
            this._screenToWorld(new Vec2(loc.x, loc.y), this.arrastraVec);
            const aim = this.screenToWorldOnZ(loc.x, loc.y, origin.z, this._tmp);
            // 2) Limita el punto al radio máximo desde puntoinicial
            const clamped = this._clampToCircle(this.puntoinicial, new Vec3(loc.x, loc.y, 0), this.maxStretch);

            // 3) ¡Mueve la pelota en MUNDO! (antes usabas loc.x/loc.y: eso eran coords de pantalla)
            this.node.setWorldPosition(clamped);
            this.Arrow.updateArrow(origin,new Vec3(loc.x,loc.y,0), this.aimInvert, 1/60 );
        }
        
    }

    Cancel() {
        if (!this.tocando) return;
        this.tocando = false;
        this.lanza = true;   // disparamos en update() para un solo lugar de lógica
        this.siguePelota = true;
        this.rb.angularVelocity = 5;
        this.camara.empieza = true;
        if (this.Arrow) this.Arrow.hide();
        this.puedetocar = false;
    }

    _screenToWorld(posUi: Vec2, outvec: Vec3) {
        this.Camara2D.screenToWorld(new Vec3(posUi.x, posUi.y, 0), outvec);
    }

    // Clamp a un círculo: desde "center" hacia "p", con radio "r"
    private _clampToCircle(center: Vec3, p: Vec3, r: number): Vec3 {
        const dx = p.x - center.x;
        const dy = p.y - center.y;
        const d = Math.hypot(dx, dy);
        if (d <= r || d == 0) return p;
        const s = r / d;
        return new Vec3(center.x + dx * s, center.y + dy * s, 0);
    }

    // (Si quisieras regresar suave a la base en algún caso)
    regresaPos(deltaTime: number) {
        const newX = math.lerp(this.node.position.x, this.puntoinicial.x, 0.5 * deltaTime);
        const newY = math.lerp(this.node.position.y, this.puntoinicial.y, 0.5 * deltaTime);
        this.node.setPosition(new Vec3(newX, newY, 0));
    }

    // Calcula vector base->actual, lo invierte y aplica impulso escalado
    lanzaPelota() {
        // Toma la posición actual de la bola (ya clamp-eada)
        const B = this.node.worldPosition;

        // Vector “estiramiento” = base -> bola
        // Para lanzar en sentido contrario, usamos base - bola (ya volteado)
        const v = new Vec2(this.puntoinicial.x - B.x, this.puntoinicial.y - B.y);

        // Escala por potencia
        const impulse = new Vec2(v.x * this.power, v.y * this.power);

        //this.rb.awake = true;
        this.rb.applyLinearImpulseToCenter(impulse, true);
    }

    update(deltaTime: number) {
        if (this.lanza) {
            this.areaTouch.active = false;
            this.lanzaPelota();
            this.rb.gravityScale=1;
            this.scheduleOnce(function(){
                this.camara.empieza = false;
                this.camara.regresa = true;
            },1.5)
            this.lanza = false;
        }
          // Si estás arrastrando, puedes volver a llamar para suavizar longitud con dt real:
        if (this.tocando && this.Arrow && this.Arrow.node.active) {
            // Mantén la flecha pegada a la pelota aunque la pelota se mueva antes de soltar
            const origin = this.node.worldPosition;
        }
    }
}
