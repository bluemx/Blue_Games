import { _decorator, CCBoolean, CCInteger, Component, instantiate, Label, Node, Prefab } from 'cc';
import { Tiro_Pelota } from './Tiro-Pelota';
import { ZoomOut } from './ZoomOut';
import { ButtonMessage } from './ButtonMessage';
const { ccclass, property } = _decorator;

@ccclass('ManagerScore')
export class ManagerScore extends Component {

    @property(CCInteger)
    public score : number = 0;
    @property(Label)
    public ScoreText : Label = null;
    @property(Label)
    public Text : Label = null;
    @property(Label)
    public mensaje : Label = null;
    @property(Node)
    public GameOver : Node = null;
    @property(CCBoolean)
    public gameOve : boolean = false;
    @property(Tiro_Pelota)
    public tiroPelota : Tiro_Pelota = null;
    @property(Node)
    public Posporteria : Node = null;
    @property(ZoomOut)
    public camaraZoom : ZoomOut = null;

    private indexNivel : number =0;
    @property([Node])
    public niveles : Node [] = [];
    @property(Prefab)
    public porteria : Prefab = null;
    protected onLoad(): void {
        this.GameOver.active = false;
    }
    start() {

        this.niveles[this.indexNivel].active= true;
        this.camaraZoom.porteria = this.niveles[this.indexNivel].children[0];
        this.Posporteria = instantiate(this.porteria);
        this.Posporteria.setParent(this.niveles[this.indexNivel].children[0]);
    }
    ActualizarScore( n : number){
        this.score +=n;
        this.Text.string = this.score.toString();
    }
    Over(){
        
        this.ScoreText.string = this.score.toString();
        if(this.score <3){
            this.mensaje.string = "Vuelve a intentar...";
            this.mensaje.fontSize = 40;
        }
        else{
            this.mensaje.string = "Felicidades";
            this.mensaje.fontSize = 70;
        }
        this.gameOve = true;
        this.GameOver.active = true;
        this.node.getComponent(ButtonMessage).sendMessageToParent();
    }
    Reinicia(){
        if(!this.gameOve){
            this.tiroPelota.Reinicia();
            this.gameOve = true;
            this.scheduleOnce(function(){
                this.gameOve = false;
            },1);
        }
       

    }
    AsignaNuevaPort(){
        this.Posporteria = instantiate(this.porteria);
        this.Posporteria.setParent(this.niveles[this.indexNivel].children[0]);
        this.camaraZoom.porteria = this.niveles[this.indexNivel].children[0];

    }
    pasaNivel(){
        
        this.scheduleOnce(function(){
            this.niveles[this.indexNivel].active = false;
            this.Posporteria.destroy();
            
            this.indexNivel ++;
            
           

            if(this.indexNivel >= this.niveles.length){
                this.Over();
                
            }
            else{
                 this.tiroPelota.intentos = 0;
                this.AsignaNuevaPort();
                this.Reinicia();
                this.niveles[this.indexNivel].active = true;
            }
            this.tiroPelota.camara.CamInicio();
        },5)
    }
    update(deltaTime: number) {
        
    }
}


