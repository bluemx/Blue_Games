System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Graphics, Color, Vec3, math, Node, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _crd, ccclass, property, AimArrow;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Graphics = _cc.Graphics;
      Color = _cc.Color;
      Vec3 = _cc.Vec3;
      math = _cc.math;
      Node = _cc.Node;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "c33d1OTrFxDG6sEXhwuSdTn", "AimArrow", undefined); // AimArrow.ts


      __checkObsolete__(['_decorator', 'Component', 'Graphics', 'Color', 'Vec3', 'math', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("AimArrow", AimArrow = (_dec = ccclass('AimArrow'), _dec2 = property(Graphics), _dec3 = property({
        tooltip: 'Ancho de la línea de la flecha'
      }), _dec4 = property({
        tooltip: 'Largo de la cabeza de flecha'
      }), _dec5 = property({
        tooltip: 'Ancho total de la cabeza de flecha'
      }), _dec6 = property({
        tooltip: 'Escala mínima de la flecha (pixeles)'
      }), _dec7 = property({
        tooltip: 'Escala máxima de la flecha (pixeles)'
      }), _dec8 = property({
        tooltip: 'Suavizado (1/seg) para que la longitud no brinque'
      }), _dec9 = property(Node), _dec(_class = (_class2 = class AimArrow extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "g", _descriptor, this);

          _initializerDefineProperty(this, "lineWidth", _descriptor2, this);

          _initializerDefineProperty(this, "headLen", _descriptor3, this);

          _initializerDefineProperty(this, "headWidth", _descriptor4, this);

          _initializerDefineProperty(this, "minLen", _descriptor5, this);

          _initializerDefineProperty(this, "maxLen", _descriptor6, this);

          _initializerDefineProperty(this, "dampingLen", _descriptor7, this);

          _initializerDefineProperty(this, "areaTouch", _descriptor8, this);

          this._visible = false;
          this._targetLen = 0;
          this._currentLen = 0;
        }

        onLoad() {
          if (!this.g) {
            this.g = this.getComponent(Graphics);
          }

          this.g.lineWidth = this.lineWidth;
          this.g.strokeColor = new Color(255, 255, 255, 255); // blanco

          this.g.fillColor = new Color(255, 255, 255, 255);
          this.hide();
        }

        show() {
          this._visible = true;
          this.node.active = true;
        }

        hide() {
          this._visible = false;
          this.node.active = false;
          this.g.clear();
          this._currentLen = 0;
          this._targetLen = 0;
        }
        /**
         * Dibuja/actualiza la flecha.
         * @param origin Posición mundo del inicio (la pelota).
         * @param aim Posición mundo del puntero/arrastre.
         * @param invert Si true, la flecha apunta en sentido contrario (útil para “estirar hacia atrás” como tirachinas).
         * @param dt delta time para suavizado de longitud.
         */


        updateArrow(origin, aim, invert, dt) {
          if (!this._visible) return; // Ubica el nodo en el origen y oriéntalo hacia "aim"

          this.node.setWorldPosition(this.areaTouch.worldPosition);
          const dir = new Vec3(aim.x - this.areaTouch.worldPosition.x, aim.y - this.areaTouch.worldPosition.y, 0);
          if (invert) dir.multiplyScalar(-5);
          const angleRad = Math.atan2(dir.y, dir.x);
          const angleDeg = angleRad * 180 / Math.PI; // Rotar el nodo para que su eje +X apunte hacia "aim"

          this.node.setRotationFromEuler(0, 0, angleDeg); // Longitud objetivo (clamp)

          this._targetLen = math.clamp(dir.length(), this.minLen, this.maxLen); // Suavizado de longitud para evitar “saltitos”

          const t = 1 - Math.exp(-this.dampingLen * dt);
          this._currentLen = math.lerp(this._currentLen, this._targetLen, t); // Dibujo en espacio local (eje +X)

          const len = this._currentLen;
          const hl = this.headLen;
          const hw = this.headWidth * 0.5;
          this.g.clear(); // Cuerpo de la flecha

          this.g.moveTo(0, 0);
          this.g.lineTo(Math.max(0, len - hl), 0);
          this.g.stroke(); // Cabeza de flecha (triángulo)

          this.g.moveTo(len, 0);
          this.g.lineTo(len - hl, hw);
          this.g.lineTo(len - hl, -hw);
          this.g.close();
          this.g.fill();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "g", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "lineWidth", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 6;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "headLen", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 30;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "headWidth", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 24;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "minLen", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 20;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "maxLen", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 300;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "dampingLen", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 20;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "areaTouch", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=82b8120f94151fef5b9d3ef9be1ac858aaed1cfd.js.map