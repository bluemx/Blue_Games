System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///E:/PuntosFutbol-2026/Super_Tiro/assets/Script/Deteccion.ts at runtime.
      throw new Error(`SyntaxError: C:\Program Files (x86)\CocosDashboard\file:\E:\PuntosFutbol-2026\Super_Tiro\assets\Script\Deteccion.ts: Unexpected token, expected "," (31:17)

  29 |                 this.scheduleOnce(function(){
  30 |                     this.MScore.Over();
> 31 |                 }.3);
     |                  ^
  32 |                 break;
  33 |             case 1:
  34 |                 // estrellas suma puntos...`);
    }
  };
});
//# sourceMappingURL=b26c37c8d730d48de78c31f0942076c3f29a4be6.js.map