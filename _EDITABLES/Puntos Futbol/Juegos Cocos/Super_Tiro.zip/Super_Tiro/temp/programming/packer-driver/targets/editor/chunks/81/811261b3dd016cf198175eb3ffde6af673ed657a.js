System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, CCBoolean, CCInteger, Component, instantiate, Label, Node, Prefab, Tiro_Pelota, ZoomOut, ButtonMessage, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _crd, ccclass, property, ManagerScore;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfTiro_Pelota(extras) {
    _reporterNs.report("Tiro_Pelota", "./Tiro-Pelota", _context.meta, extras);
  }

  function _reportPossibleCrUseOfZoomOut(extras) {
    _reporterNs.report("ZoomOut", "./ZoomOut", _context.meta, extras);
  }

  function _reportPossibleCrUseOfButtonMessage(extras) {
    _reporterNs.report("ButtonMessage", "./ButtonMessage", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      CCBoolean = _cc.CCBoolean;
      CCInteger = _cc.CCInteger;
      Component = _cc.Component;
      instantiate = _cc.instantiate;
      Label = _cc.Label;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
    }, function (_unresolved_2) {
      Tiro_Pelota = _unresolved_2.Tiro_Pelota;
    }, function (_unresolved_3) {
      ZoomOut = _unresolved_3.ZoomOut;
    }, function (_unresolved_4) {
      ButtonMessage = _unresolved_4.ButtonMessage;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "97b47OU0LNARrZg6PNf90OY", "ManagerScore", undefined);

      __checkObsolete__(['_decorator', 'CCBoolean', 'CCInteger', 'Component', 'instantiate', 'Label', 'Node', 'Prefab']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("ManagerScore", ManagerScore = (_dec = ccclass('ManagerScore'), _dec2 = property(CCInteger), _dec3 = property(Label), _dec4 = property(Label), _dec5 = property(Label), _dec6 = property(Node), _dec7 = property(CCBoolean), _dec8 = property(_crd && Tiro_Pelota === void 0 ? (_reportPossibleCrUseOfTiro_Pelota({
        error: Error()
      }), Tiro_Pelota) : Tiro_Pelota), _dec9 = property(Node), _dec10 = property(_crd && ZoomOut === void 0 ? (_reportPossibleCrUseOfZoomOut({
        error: Error()
      }), ZoomOut) : ZoomOut), _dec11 = property([Node]), _dec12 = property(Prefab), _dec(_class = (_class2 = class ManagerScore extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "score", _descriptor, this);

          _initializerDefineProperty(this, "ScoreText", _descriptor2, this);

          _initializerDefineProperty(this, "Text", _descriptor3, this);

          _initializerDefineProperty(this, "mensaje", _descriptor4, this);

          _initializerDefineProperty(this, "GameOver", _descriptor5, this);

          _initializerDefineProperty(this, "gameOve", _descriptor6, this);

          _initializerDefineProperty(this, "tiroPelota", _descriptor7, this);

          _initializerDefineProperty(this, "Posporteria", _descriptor8, this);

          _initializerDefineProperty(this, "camaraZoom", _descriptor9, this);

          this.indexNivel = 0;

          _initializerDefineProperty(this, "niveles", _descriptor10, this);

          _initializerDefineProperty(this, "porteria", _descriptor11, this);
        }

        onLoad() {
          this.GameOver.active = false;
        }

        start() {
          this.niveles[this.indexNivel].active = true;
          this.camaraZoom.porteria = this.niveles[this.indexNivel].children[0];
          this.Posporteria = instantiate(this.porteria);
          this.Posporteria.setParent(this.niveles[this.indexNivel].children[0]);
        }

        ActualizarScore(n) {
          this.score += n;
          this.Text.string = this.score.toString();
        }

        Over() {
          this.ScoreText.string = this.score.toString();

          if (this.score < 3) {
            this.mensaje.string = "Vuelve a intentar...";
            this.mensaje.fontSize = 40;
          } else {
            this.mensaje.string = "Felicidades";
            this.mensaje.fontSize = 70;
          }

          this.gameOve = true;
          this.GameOver.active = true;
          this.node.getComponent(_crd && ButtonMessage === void 0 ? (_reportPossibleCrUseOfButtonMessage({
            error: Error()
          }), ButtonMessage) : ButtonMessage).sendMessageToParent();
        }

        Reinicia() {
          if (!this.gameOve) {
            this.tiroPelota.Reinicia();
            this.gameOve = true;
            this.scheduleOnce(function () {
              this.gameOve = false;
            }, 1);
          }
        }

        AsignaNuevaPort() {
          this.Posporteria = instantiate(this.porteria);
          this.Posporteria.setParent(this.niveles[this.indexNivel].children[0]);
          this.camaraZoom.porteria = this.niveles[this.indexNivel].children[0];
        }

        pasaNivel() {
          this.scheduleOnce(function () {
            this.niveles[this.indexNivel].active = false;
            this.Posporteria.destroy();
            this.indexNivel++;

            if (this.indexNivel >= this.niveles.length) {
              this.Over();
            } else {
              this.tiroPelota.intentos = 0;
              this.AsignaNuevaPort();
              this.Reinicia();
              this.niveles[this.indexNivel].active = true;
            }

            this.tiroPelota.camara.CamInicio();
          }, 5);
        }

        update(deltaTime) {}

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "score", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 0;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "ScoreText", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "Text", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "mensaje", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "GameOver", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "gameOve", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return false;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "tiroPelota", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "Posporteria", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "camaraZoom", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "niveles", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "porteria", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=811261b3dd016cf198175eb3ffde6af673ed657a.js.map