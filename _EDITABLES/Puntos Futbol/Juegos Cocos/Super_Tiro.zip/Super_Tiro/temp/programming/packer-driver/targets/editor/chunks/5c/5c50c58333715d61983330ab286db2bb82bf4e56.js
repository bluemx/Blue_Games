System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, CCBoolean, CCInteger, Component, instantiate, Label, Node, Prefab, Tiro_Pelota, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _crd, ccclass, property, ManagerScore;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfTiro_Pelota(extras) {
    _reporterNs.report("Tiro_Pelota", "./Tiro-Pelota", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      CCBoolean = _cc.CCBoolean;
      CCInteger = _cc.CCInteger;
      Component = _cc.Component;
      instantiate = _cc.instantiate;
      Label = _cc.Label;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
    }, function (_unresolved_2) {
      Tiro_Pelota = _unresolved_2.Tiro_Pelota;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "97b47OU0LNARrZg6PNf90OY", "ManagerScore", undefined);

      __checkObsolete__(['_decorator', 'CCBoolean', 'CCInteger', 'Component', 'instantiate', 'Label', 'Node', 'Prefab']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("ManagerScore", ManagerScore = (_dec = ccclass('ManagerScore'), _dec2 = property(CCInteger), _dec3 = property(Label), _dec4 = property(Label), _dec5 = property(Node), _dec6 = property(CCBoolean), _dec7 = property(_crd && Tiro_Pelota === void 0 ? (_reportPossibleCrUseOfTiro_Pelota({
        error: Error()
      }), Tiro_Pelota) : Tiro_Pelota), _dec8 = property(Node), _dec9 = property([Node]), _dec10 = property(Prefab), _dec(_class = (_class2 = class ManagerScore extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "score", _descriptor, this);

          _initializerDefineProperty(this, "ScoreText", _descriptor2, this);

          _initializerDefineProperty(this, "Text", _descriptor3, this);

          _initializerDefineProperty(this, "GameOver", _descriptor4, this);

          _initializerDefineProperty(this, "gameOve", _descriptor5, this);

          _initializerDefineProperty(this, "tiroPelota", _descriptor6, this);

          _initializerDefineProperty(this, "Posporteria", _descriptor7, this);

          this.indexNivel = 11;

          _initializerDefineProperty(this, "niveles", _descriptor8, this);

          _initializerDefineProperty(this, "porteria", _descriptor9, this);
        }

        onLoad() {
          this.GameOver.active = false;
        }

        start() {
          this.niveles[this.indexNivel].active = true;
          this.Posporteria = instantiate(this.porteria);
          this.Posporteria.setParent(this.niveles[this.indexNivel].children[0]);
        }

        ActualizarScore() {
          this.score += 1;
          this.Text.string = this.score.toString();
        }

        Over() {
          this.gameOve = true;
          this.GameOver.active = true;
        }

        Reinicia() {
          if (!this.gameOve) {
            this.tiroPelota.Reinicia();
            this.gameOve = true;
            this.scheduleOnce(function () {
              this.gameOve = false;
            }, 1);
          }
        }

        AsignaNuevaPort() {
          this.Posporteria = instantiate(this.porteria);
          this.Posporteria.setParent(this.niveles[this.indexNivel].children[0]);
        }

        pasaNivel() {
          this.scheduleOnce(function () {
            this.niveles[this.indexNivel].active = false;
            this.Posporteria.destroy();
            this.tiroPelota.camara.CamInicio();
            this.indexNivel++;
            this.tiroPelota.intentos = 0;
            this.AsignaNuevaPort();
            this.Reinicia();
            this.niveles[this.indexNivel].active = true;
          }, 5);
        }

        update(deltaTime) {}

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "score", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 0;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "ScoreText", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "Text", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "GameOver", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "gameOve", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return false;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "tiroPelota", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "Posporteria", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "niveles", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "porteria", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=5c50c58333715d61983330ab286db2bb82bf4e56.js.map