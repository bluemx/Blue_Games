System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///E:/PuntosFutbol-2026/Super_Tiro/assets/Script/Tiro-Pelota.ts at runtime.
      throw new Error(`SyntaxError: C:\Program Files (x86)\CocosDashboard\file:\E:\PuntosFutbol-2026\Super_Tiro\assets\Script\Tiro-Pelota.ts: Unexpected token (145:0)

  143 |         }
  144 | }
> 145 |
      | ^`);
    }
  };
});
//# sourceMappingURL=52240b8516974ca1a0d80b69ae6f697d970f1743.js.map