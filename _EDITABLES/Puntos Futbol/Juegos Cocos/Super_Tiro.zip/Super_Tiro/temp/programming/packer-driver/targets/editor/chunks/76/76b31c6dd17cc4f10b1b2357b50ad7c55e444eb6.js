System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Camera, CCBoolean, CCInteger, Component, math, Node, Vec3, Tiro_Pelota, UITransform, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _dec11, _dec12, _dec13, _dec14, _dec15, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _descriptor9, _descriptor10, _descriptor11, _descriptor12, _descriptor13, _descriptor14, _descriptor15, _descriptor16, _crd, ccclass, property, ZoomOut;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfTiro_Pelota(extras) {
    _reporterNs.report("Tiro_Pelota", "./Tiro-Pelota", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Camera = _cc.Camera;
      CCBoolean = _cc.CCBoolean;
      CCInteger = _cc.CCInteger;
      Component = _cc.Component;
      math = _cc.math;
      Node = _cc.Node;
      Vec3 = _cc.Vec3;
      UITransform = _cc.UITransform;
    }, function (_unresolved_2) {
      Tiro_Pelota = _unresolved_2.Tiro_Pelota;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "882d32SWVlFaY1FhKObdURE", "ZoomOut", undefined);

      __checkObsolete__(['_decorator', 'Camera', 'CCBoolean', 'CCInteger', 'Component', 'math', 'Node', 'postProcess', 'Vec3']);

      __checkObsolete__(['UITransform']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("ZoomOut", ZoomOut = (_dec = ccclass('ZoomOut'), _dec2 = property(Node), _dec3 = property(CCInteger), _dec4 = property(CCInteger), _dec5 = property(Camera), _dec6 = property(CCBoolean), _dec7 = property(Node), _dec8 = property(Node), _dec9 = property(Node), _dec10 = property(_crd && Tiro_Pelota === void 0 ? (_reportPossibleCrUseOfTiro_Pelota({
        error: Error()
      }), Tiro_Pelota) : Tiro_Pelota), _dec11 = property(Vec3), _dec12 = property(CCInteger), _dec13 = property(CCInteger), _dec14 = property(CCBoolean), _dec15 = property(CCBoolean), _dec(_class = (_class2 = class ZoomOut extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "piso", _descriptor, this);

          _initializerDefineProperty(this, "bottomPadding", _descriptor2, this);

          _initializerDefineProperty(this, "limiteCamara", _descriptor3, this);

          _initializerDefineProperty(this, "InfCamara", _descriptor4, this);

          _initializerDefineProperty(this, "CameraZoom", _descriptor5, this);

          _initializerDefineProperty(this, "empieza", _descriptor6, this);

          _initializerDefineProperty(this, "pelota", _descriptor7, this);

          _initializerDefineProperty(this, "porteria", _descriptor8, this);

          _initializerDefineProperty(this, "PosCam", _descriptor9, this);

          _initializerDefineProperty(this, "tira", _descriptor10, this);

          // --- NUEVOS AJUSTES PARA UN SEGUIMIENTO SUAVE ---
          _initializerDefineProperty(this, "offset", _descriptor11, this);

          // Desplazamiento vertical
          _initializerDefineProperty(this, "damping", _descriptor12, this);

          // Suavizado (1/seg). 8-12 es buen rango
          _initializerDefineProperty(this, "deadZone", _descriptor13, this);

          // Radio (pixeles) para ignorar micro-movimientos
          _initializerDefineProperty(this, "maxFollowSpeed", _descriptor14, this);

          // Límite de velocidad (pixeles/seg) para evitar “tirones”
          this._tmp = new Vec3();

          _initializerDefineProperty(this, "regresa", _descriptor15, this);

          _initializerDefineProperty(this, "inicio", _descriptor16, this);

          this.comienza = false;
          this.zoom = false;
        }

        onLoad() {}

        start() {
          this.CamInicio();
        }

        CamInicio() {
          //this.CameraZoom.orthoHeight = this.limiteCamara;
          this.inicio = true;
          this.empieza = true;
          this.regresa = false;
          this.scheduleOnce(function () {
            this.inicio = false;
            this.empieza = false;
            this.regresa = true;
          }, 2.5);
        }

        followTarget(targetN, dt) {
          if (!targetN) return; // Usar posiciones en WORLD para evitar diferencias por padres distintos

          const target = new Vec3();
          const current = new Vec3();
          targetN.getWorldPosition(target);
          this.node.getWorldPosition(current); // Aplicar offset deseado (p.ej. mirar un poco por encima)

          Vec3.add(target, target, this.offset); // Vector hacia el objetivo

          Vec3.subtract(this._tmp, target, current);

          const dist = this._tmp.length(); // Zona muerta: si estamos suficientemente cerca, no muevas la cámara


          if (dist < this.deadZone) return; // Exponential smoothing independiente del framerate:
          // t = 1 - e^(-lambda * dt)

          const t = 1 - Math.exp(-this.damping * dt); // Paso deseado suavizado

          const step = new Vec3(this._tmp.x * t, this._tmp.y * t, 0); // Clamp por velocidad máxima para evitar saltos bruscos

          const maxStep = this.maxFollowSpeed * dt;
          const stepLen = step.length();

          if (stepLen > maxStep) {
            step.multiplyScalar(maxStep / stepLen);
          } // Nueva posición en world (mantén Z actual)


          const desired = new Vec3(current.x + step.x, current.y + step.y, current.z);
          const groundTopY = this.getGroundTopY();
          const minCamCenterY = groundTopY + this.CameraZoom.orthoHeight + this.bottomPadding;
          desired.y = Math.max(desired.y, minCamCenterY);
          this.node.setWorldPosition(desired);
        }

        getGroundTopY() {
          if (!this.piso) return -Infinity;
          const ui = this.piso.getComponent(UITransform);
          if (!ui) return -Infinity;
          const wp = this.piso.worldPosition;
          const sy = this.piso.worldScale.y; // top = worldY + (1 - anchorY) * alto * escala

          return wp.y;
        }

        zoomOut(deltaTime) {
          this.CameraZoom.orthoHeight = math.lerp(this.CameraZoom.orthoHeight, this.limiteCamara, 0.5 * deltaTime);
        }

        zoomIn(deltaTime) {
          this.CameraZoom.orthoHeight = math.lerp(this.CameraZoom.orthoHeight, this.InfCamara, 0.5 * deltaTime);
        }

        update(deltaTime) {
          if (this.empieza && !this.regresa) {
            this.zoomOut(deltaTime);
            this.followTarget(this.porteria, deltaTime);
          } else if (!this.empieza && this.regresa) {
            this.followTarget(this.pelota, deltaTime); //console.log("siguiendo pelota");

            this.zoomIn(deltaTime); //this.zoomIn(deltaTime);
          }
        } // Seguir a la pelota DESPUÉS de que todo se movió este frame -> menos jitter


        lateUpdate(deltaTime) {
          /* if(this.inicio){
               this.followTarget(this.porteria,deltaTime);
             }
           else if (!this.inicio && this.tira.puedetocar){
               this.followTarget(this.PosCam,deltaTime);
               this.zoomIn(deltaTime)
             }*/
          if (this.tira && this.tira.siguePelota) {
            this.followTarget(this.pelota, deltaTime);
            this.zoomOut(deltaTime);
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "piso", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "bottomPadding", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 0;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "limiteCamara", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 0;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "InfCamara", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 0;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "CameraZoom", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "empieza", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return false;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "pelota", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "porteria", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor9 = _applyDecoratedDescriptor(_class2.prototype, "PosCam", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor10 = _applyDecoratedDescriptor(_class2.prototype, "tira", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor11 = _applyDecoratedDescriptor(_class2.prototype, "offset", [_dec11], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return new Vec3(0, 50, 0);
        }
      }), _descriptor12 = _applyDecoratedDescriptor(_class2.prototype, "damping", [property], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 10;
        }
      }), _descriptor13 = _applyDecoratedDescriptor(_class2.prototype, "deadZone", [_dec12], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 6;
        }
      }), _descriptor14 = _applyDecoratedDescriptor(_class2.prototype, "maxFollowSpeed", [_dec13], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 2000;
        }
      }), _descriptor15 = _applyDecoratedDescriptor(_class2.prototype, "regresa", [_dec14], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return false;
        }
      }), _descriptor16 = _applyDecoratedDescriptor(_class2.prototype, "inicio", [_dec15], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return false;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=76b31c6dd17cc4f10b1b2357b50ad7c55e444eb6.js.map