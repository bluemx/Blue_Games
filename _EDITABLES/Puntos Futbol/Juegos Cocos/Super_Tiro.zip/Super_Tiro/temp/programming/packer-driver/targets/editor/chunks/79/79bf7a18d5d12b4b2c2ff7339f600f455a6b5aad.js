System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Score, _dec, _dec2, _class, _class2, _descriptor, _crd, ccclass, property, ButtonMessage;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfScore(extras) {
    _reporterNs.report("Score", "./Score", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_unresolved_2) {
      Score = _unresolved_2.Score;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "4f459zNtGlOZoG6cRzN00BN", "ButtonMessage", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Button']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("ButtonMessage", ButtonMessage = (_dec = ccclass('ButtonMessage'), _dec2 = property(_crd && Score === void 0 ? (_reportPossibleCrUseOfScore({
        error: Error()
      }), Score) : Score), _dec(_class = (_class2 = class ButtonMessage extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "manScore", _descriptor, this);
        }

        sendMessageToParent() {
          var _window$parent;

          (_window$parent = window.parent) == null || _window$parent.postMessage({
            score: this.manScore.score
          }, '*');
        }

        sendMessageToExit() {
          var _window$parent2;

          (_window$parent2 = window.parent) == null || _window$parent2.postMessage({
            state: 'exit'
          }, '*');
        }

        sendMessageToRestart() {
          var _window$parent3;

          (_window$parent3 = window.parent) == null || _window$parent3.postMessage({
            status: 'reset'
          }, '*');
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "manScore", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=79bf7a18d5d12b4b2c2ff7339f600f455a6b5aad.js.map