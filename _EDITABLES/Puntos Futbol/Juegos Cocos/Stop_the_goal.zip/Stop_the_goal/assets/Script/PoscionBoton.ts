import { _decorator, CCInteger, Component, find, Node } from 'cc';
import { SeleccionEquipo } from './SeleccionEquipo';
const { ccclass, property } = _decorator;

@ccclass('PoscionBoton')
export class PoscionBotono extends Component {
    @property(CCInteger)
    public pos : number = 0;
    @property(SeleccionEquipo)
    public Ms : SeleccionEquipo = null;

    protected onLoad(): void {
        this.Ms = find("ManagerSeleccion").getComponent(SeleccionEquipo);
    }
    start() {

    }

    SetPosSeleccion(){
        console.log("la posicion es  "+ this.pos);
        this.Ms.posSeleccion = this.pos;
        this.Ms.CambiaSeleccion();

        
    }
    update(deltaTime: number) {
        
    }
}


