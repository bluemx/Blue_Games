import { _decorator, Component, Node, NodeEventType, IPhysics2DContact,Collider, Collider2D, Contact2DType, RigidBody, RigidBody2D } from 'cc';
import { ManagerGame } from './ManagerGame';
import { Score } from './Score';
const { ccclass, property } = _decorator;

@ccclass('Muerte')
export class Muerte extends Component {

  

    protected onLoad(): void {

         const collider = this.getComponent(Collider2D);
         if(collider){
            collider.on(Contact2DType.END_CONTACT, this.onTriggerEnter, this);
         }
        
    }
    start() {

    }
    onTriggerEnter(selfCollider : Collider2D, otherCollider: Collider2D, contact : IPhysics2DContact){
       
        console.log(otherCollider.group.toString());
        switch(otherCollider.group){
            case 2:
                //jugador
                
                break;
            case 4:
                //balon
                this.scheduleOnce(function(){
                   
                    otherCollider.node.destroy();
            },1)
                break;
            
        }
       
    }
   
    update(deltaTime: number) {
        
    }
}


