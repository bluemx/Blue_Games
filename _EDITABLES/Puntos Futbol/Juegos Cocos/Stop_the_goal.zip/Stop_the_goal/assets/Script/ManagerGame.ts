import { _decorator, CCBoolean, Component, Node, postProcess, ProgressBarComponent } from 'cc';
import { Score } from './Score';
import { ButtonMessage } from './ButtonMessage';
const { ccclass, property } = _decorator;

@ccclass('ManagerGame')
export class ManagerGame extends Component {
    @property(CCBoolean)
    public GameOver : boolean = false;
    @property(Node)
    public Over : Node = null;
    @property([Node])
    public mensajes : Node [] =  [];
    @property([Node])
    public numeros : Node [] = [];
    protected onLoad(): void {
        this.Over.active = false;
        this.GameOver = false;
        this.numeros[0].active= false;
        this.numeros[1].active= false;
        this.numeros[2].active= false;
        this.numeros[0].active = true;

        this.scheduleOnce(function(){
            this.numeros[0].active = false;
            this.numeros[1].active = true;
            this.scheduleOnce(function(){
            this.numeros[1].active = false;
            this.numeros[2].active = true;
                this.scheduleOnce(function(){
                    this.numeros[2].active =  false;
                    this.node.getComponent(Score).comienza=true;
                },1)   
            },1);
        },1);

    }
    
    start() {

    }
    Game(){
        if(this.GameOver){
            this.node.getComponent(Score).comienza = false;
            if(this.node.getComponent(Score).score>5){
                this.mensajes[0].active=false;
                this.mensajes[1].active=true;
            }
            else{
                 this.mensajes[0].active=true;
                this.mensajes[1].active=false;
            }
            this.Over.active = true;
            this.Over.getComponent(ButtonMessage).sendMessageToParent();
            this.node.getComponent(Score).finalScoreText.string =  this.node.getComponent(Score).scoreText.string 
        }
    }

    update(deltaTime: number) {
        
    }
}


