import { _decorator, CCBoolean, CCFloat, CCInteger, Component, instantiate, Node, Prefab, randomRangeInt, RigidBody2D, Sprite, SpriteFrame, Vec3, Vec2} from 'cc';
import { Equipos } from './Equipos';
const { ccclass, property } = _decorator;

@ccclass('SpawnBalon')
export class SpawnBalon extends Component {
    @property(Equipos)
    public manager : Equipos = null;
    @property([SpriteFrame])
    public enemigos : SpriteFrame [] = [];
    @property([Node])
    public posicionestiro : Node [] = [];
    @property(Prefab)
    public balonSpawn : Prefab = null;
    @property(Node)
    public fondo : Node = null;
    @property(CCBoolean)
    public game : boolean = false;
    @property(CCBoolean)
    public creando : boolean = false;
    @property(CCFloat)
    private tiempoSpawn : number = 1.5;

    protected onLoad(): void {

        this.manager = Equipos._instance;
        this.node.getComponent(Sprite).spriteFrame = this.enemigos[this.manager.posPc];

        this.scheduleOnce(function(){
            this.tirobalon();
            this.game = true;
        },3)
    }
    start() {

    }
    tirobalon(){
        const random = randomRangeInt(0,5);
        this.node.setPosition(this.posicionestiro[random].position);

        const node = instantiate(this.balonSpawn);
        node.setParent(this.fondo);
        node.setPosition(new Vec3(this.posicionestiro[random].position.x, 280, 0));
        const tirorandom = randomRangeInt ( 0,3);
        switch(random){
            case 0:
                node.getComponent(RigidBody2D).applyLinearImpulseToCenter(new Vec2(10,0), true);
                break;
            case 1: 
                node.getComponent(RigidBody2D).applyLinearImpulseToCenter(new Vec2(0,0), true);
                break;
            case 2: 
            node.getComponent(RigidBody2D).applyLinearImpulseToCenter(new Vec2(-10,0), true);
                break;
            case 3:
                node.getComponent(RigidBody2D).applyLinearImpulseToCenter(new Vec2(-5,0), true);
                break;
            case 4:
                node.getComponent(RigidBody2D).applyLinearImpulseToCenter(new Vec2(5,0), true);
                break;
        }
    }
    update(deltaTime: number) {
        if(this.game){
            if(!this.creando){
                this.creando = true;

                this.scheduleOnce(function(){
                    this.tirobalon();
                    this.creando = false;
                    this.tiempoSpawn -= .025;
                    if(this.tiempoSpawn < .6){
                        this.tiempoSpawn =.6;
                    }
                }, this.tiempoSpawn)
            }
        }
    }
}


