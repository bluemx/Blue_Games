import { _decorator, Collider, Collider2D, Component, IPhysics2DContact, Contact2DType, Node, CCInteger } from 'cc';
import { ManagerGame } from './ManagerGame';
import { SpawnBalon } from './SpawnBalon';
const { ccclass, property } = _decorator;

@ccclass('balon')
export class balon extends Component {
    @property(Collider2D)
    public collision : Collider2D = null;

     @property(ManagerGame)
    public Manager : ManagerGame = null; 
    @property(CCInteger)
    public goles : number = 0;
    @property(SpawnBalon)
    public balones : SpawnBalon = null;

    protected onLoad(): void {
        this.collision = this.getComponent(Collider2D);

        this.collision.on(Contact2DType.BEGIN_CONTACT, this.ontrigger, this);
    }

    ontrigger(selfCollider : Collider2D, otherCollider: Collider2D, contact : IPhysics2DContact){

        //console.log(otherCollider.group.toString());

        if(otherCollider.group == 4){
            this.goles++;

            if(this.goles == 2){
                this.Manager.GameOver = true;
                this.balones.game = false;
                this.Manager.Game();
            }
        }

    }
    start() {

    }

    update(deltaTime: number) {
        
    }
}


