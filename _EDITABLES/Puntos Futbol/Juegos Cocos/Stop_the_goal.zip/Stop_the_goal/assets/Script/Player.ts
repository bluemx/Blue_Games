import { _decorator, Component, Node, Vec3, math, Sprite, CCFloat, SpriteFrame } from 'cc';
import { Equipos } from './Equipos';

const { ccclass, property } = _decorator;

@ccclass('Player')
export class Player extends Component {
    @property(Equipos)
    public equipo : Equipos = null;
    @property([SpriteFrame])
    public player : SpriteFrame[] = [];
    @property(Node)
    public Balon : Node = null;
    @property(CCFloat)
    public targetAngle : number = 0;
    protected onLoad(): void {
        this.equipo = Equipos._instance;
        this.node.children[0].getComponent(Sprite).spriteFrame = this.player[this.equipo.posPlayer];
    }
    start() {

    }

    SiguePelota(deltaTime : number){

        let newAngle = 0;
       
        this.targetAngle = math.clamp(this.targetAngle, -30, 30)
        newAngle = math.lerp(this.node.angle, -this.targetAngle, 5 *deltaTime);
        
        const newX = math.lerp(this.node.position.x, this.Balon.position.x, 2 *deltaTime);
        this.node.angle = newAngle;
        this.node.setPosition(new Vec3(newX, this.node.position.y,0));

    }
    update(deltaTime: number) {
       // this.SiguePelota(deltaTime);
    }
}


