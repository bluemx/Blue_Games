import { _decorator, Component, Node, Input, EventTouch, Vec3, Animation, RigidBody2D, NodeEventType, Contact2DType, Collider2D, Touch, CCBoolean, IPhysics2DContact, SpriteFrame, Sprite, CapsuleCharacterController } from 'cc';
import { Player } from './Player';
//import { Animaciones } from './Animaciones';

const { ccclass, property } = _decorator;

@ccclass('MovimientoCubeta')
export class MovimientoCubeta extends Component {
  

    @property(Node)
    public Player : Node = null;
    @property public limiteIzq:number = -300;
    @property public limiteDer:number = 300;
    @property(Node) nodeImage: Node=null;
    public posY:Vec3;

    @property
    public speed: number = 500;
    @property(Vec3)
    public targetPosition: Vec3 = new Vec3();
    @property(Vec3)
    public moveDirection: Vec3 = new Vec3();
    @property(Vec3)
    public newPosition: Vec3 = new Vec3();
    @property([SpriteFrame])
    public balosSprites : SpriteFrame [] = [];

    @property public flechas:boolean=false;
    @property public touch:  boolean = false;
    @property(Vec3) public transf: Vec3 = new Vec3();

    
    public YaEntre: boolean = false;

   
    private prevMouseX: number = 0;
    
    @property(CCBoolean)
    public choque: boolean=false;
   
    private tocando : boolean = false;

    @property(RigidBody2D)
    public body : RigidBody2D = null;
    onLoad(){
        this.choque = false;
        
        this.YaEntre=false;
        //this.anim= this.getComponent(Animaciones);
       // this.animation = this.node.getComponentInChildren(Animation)
        //this.anim.IDLE();
        this.posY=this.nodeImage.getWorldPosition();

       
       
        
        this.nodeImage.on(NodeEventType.TOUCH_START,this.Touch,this)
        this.nodeImage.on(NodeEventType.TOUCH_MOVE,this.Move,this)
        this.nodeImage.on(NodeEventType.TOUCH_END,this.Stop,this)
        this.nodeImage.on(NodeEventType.TOUCH_CANCEL,this.Stop,this)
        const collider = this.getComponent(Collider2D);
        if(collider){
            collider.on(Contact2DType.BEGIN_CONTACT, this.onTriggerEnter, this);
        }
       
       
       
    }

   

    Stop()
    {
        this.tocando = false;
        this.YaEntre = false;
        
        //console.log("regresa idle");
        this.node.getComponent(Animation).play("balon-anim");
        this.suelta();
    }
    
    Touch(event :EventTouch)
    {
        this.tocando=true;
                
       // this.node.getComponent(Animation).play("balon2-anim");
        
    }
    Move(event :EventTouch){
        if(this.tocando && !this.choque){
                let loc=event.getUILocation();
                //this.node.children[0].getComponent(Sprite).spriteFrame = this.balosSprites[0];
                // Determinar la dirección del movimiento del mouse
                const currentMouseX = event.getLocationX();
                //console.log(currentMouseX.toString());
                
                    if (currentMouseX > this.prevMouseX) {
                       
                        this.Player.getComponent(Player).targetAngle = currentMouseX;
                        this.node.children[0].getComponent(Sprite).spriteFrame = this.balosSprites[1];
                        
                    } else if (currentMouseX < this.prevMouseX) {
                        
                        this.Player.getComponent(Player).targetAngle = -currentMouseX;
                        this.node.children[0].getComponent(Sprite).spriteFrame = this.balosSprites[0];
                       
    
                    }
                
                this.prevMouseX = currentMouseX;
                
                if(loc.x < 120){
                    loc.x=120;
                }
                if(loc.x>520){
                    loc.x=520;
                }
                this.nodeImage.setWorldPosition(new Vec3(loc.x, this.posY.y, 0));
                
        }
        else{

        }
        
    }

    onTriggerEnter( selfCollider : Collider2D, otherCollider: Collider2D, contact : IPhysics2DContact)
    {
       // Supongamos que este es el nodo al que le quieres enviar el evento
      // console.log("El balon colisiono con " + otherCollider.group.toString());
        if(otherCollider.group == 8){
           this.body.gravityScale = 1;
          this.tocando=false;
           this.choque=true;

           
            
        }
        
    }
   
    suelta(){
        this.transf=this.nodeImage.getPosition();
        this.targetPosition=this.transf;
        this.nodeImage.getPosition(this.transf);

       
    }
   

   
    update(deltaTime:number)
    {
       
    }
}


