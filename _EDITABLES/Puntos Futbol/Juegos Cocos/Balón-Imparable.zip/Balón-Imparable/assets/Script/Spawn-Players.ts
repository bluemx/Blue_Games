import { _decorator, CCFloat, Component, instantiate, Node, Prefab, randomRangeInt, Sprite, SpriteFrame, SpriteRenderer } from 'cc';
import { Equipos } from './Equipos';

const { ccclass, property } = _decorator;

@ccclass('Spawn_Players')
export class Spawn_Players extends Component {
    @property(Prefab)
    public Enemigo : Prefab = null;
    @property([Node])
    public posiciones : Node[] = [];
    @property([SpriteFrame])
    public enemigos : SpriteFrame [] = [];
    @property(Equipos)
    public equipoPc : Equipos = null;

    @property(CCFloat)
    public time : number = 0;

    private yaSpawn : boolean = false;

    private index : number[] = [0,0,0,0,0];
    protected onLoad(): void {
        //this.schedule(=>this.Spawn(), this.time);
        this.equipoPc = Equipos._instance;
        
      
    }
    Spawn(){
        let x = randomRangeInt(0,5)
        const node = instantiate(this.Enemigo);
        node.getComponent(Sprite).spriteFrame = this.enemigos[this.equipoPc.posPc]
         node.setParent(this.node);
        switch(x){
            case 0: 
            node.setPosition(this.posiciones[0].position);
            this.index[0]++;
            if(this.index[0] >=1)
            {
                node.setPosition(this.posiciones[3].position);
                this.index[0] =0;
            }
            break;
            case 1: 
            node.setPosition(this.posiciones[1].position);
            this.index[1]++;
             if(this.index[1] >=1)
            {
                node.setPosition(this.posiciones[0].position);
                this.index[1] =0;
            }
            break;
            case 2: 
            node.setPosition(this.posiciones[2].position);
            this.index[2]++;
             if(this.index[2] >=1)
            {
                node.setPosition(this.posiciones[4].position);
                this.index[2] =0;
            }
            break;
            case 3:
            node.setPosition(this.posiciones[3].position);
            this.index[3]++;
             if(this.index[3] >=1)
            {
                node.setPosition(this.posiciones[2].position);
                this.index[3] =0;
            }
            break;
            case 4:
            node.setPosition(this.posiciones[4].position);
            this.index[4]++;
             if(this.index[4] >=1)
            {
                node.setPosition(this.posiciones[1].position);
                this.index[4] =0;
            }
            break;
        }
        this.yaSpawn = false;
    }
    start() {

    }
    timer (deltaTime : number){
        this.time -= deltaTime/20 ;
        if(this.time<=.5){
            this.time =.5;
        }
    }
    update(deltaTime: number) {
        
        this.timer(deltaTime);
        if(!this.yaSpawn){
            this.yaSpawn = true;
            this.scheduleOnce(function(){
                this.Spawn();
            },this.time)
            
        }

    }
}


