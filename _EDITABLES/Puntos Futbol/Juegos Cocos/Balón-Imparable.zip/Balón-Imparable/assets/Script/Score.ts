import { _decorator, CCBoolean, CCInteger, Component, Label, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('Score')
export class Score extends Component {
    @property(Label)
    public scoreText : Label = null;
    @property(Label)
    public finalScoreText : Label = null;
    @property(CCInteger)
    public score : number = 0;
    private score2 = 0;
    @property(CCBoolean)
    public comienza : boolean = false;
    start() {

    }

    sumaScore(deltaTime : number){
       
        this.score2+= deltaTime;
       
        this.score = Math.floor(this.score2);
        this.scoreText.string = this.score.toString();
        
    }
    
    update(deltaTime: number) {
        if(this.comienza){
              this.sumaScore(deltaTime);
        }
      
    }
}


