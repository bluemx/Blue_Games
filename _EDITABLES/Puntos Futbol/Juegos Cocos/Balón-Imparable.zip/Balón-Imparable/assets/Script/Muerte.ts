import { _decorator, Component, Node, NodeEventType, IPhysics2DContact,Collider, Collider2D, Contact2DType, RigidBody, RigidBody2D } from 'cc';
import { ManagerGame } from './ManagerGame';
const { ccclass, property } = _decorator;

@ccclass('Muerte')
export class Muerte extends Component {

    @property(ManagerGame)
    public Manager : ManagerGame = null; 

    protected onLoad(): void {

         const collider = this.getComponent(Collider2D);
         if(collider){
            collider.on(Contact2DType.BEGIN_CONTACT, this.onTriggerEnter, this);
         }
        
    }
    start() {

    }
    onTriggerEnter(selfCollider : Collider2D, otherCollider: Collider2D, contact : IPhysics2DContact){
       
        console.log(otherCollider.group.toString());
        switch(otherCollider.group){
            case 2:
                //jugador
                this.scheduleOnce(function(){
                    this.Manager.GameOver = true;
                    this.Manager.Game()
                },3)
                break;
            case 8:
                //enemigos
                this.scheduleOnce(function(){
                otherCollider.node.destroy();
            },1)
                break;
            
        }
       
    }
   
    update(deltaTime: number) {
        
    }
}


