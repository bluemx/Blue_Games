import { _decorator, Button, CCString, Component, Node, director, Sprite, SpriteFrame, find } from 'cc';
import { CambioEscena } from './CambioEscena';
const { ccclass, property } = _decorator;

@ccclass('ManagerSeleccion')
export class ManagerSleccion extends Component {
    public static _instance: ManagerSleccion = null;
    
   
  
    @property(CCString)
    public nameScene : String = "";
    
    protected onLoad(): void {
         if (ManagerSleccion._instance) {
            // Si ya hay uno, destruir este nuevo duplicado
            this.node.destroy();
            return;
        }
        ManagerSleccion._instance = this;
        director.addPersistRootNode(this.node);
        
    }
    start() {
        

        this.nameScene = "Seleccion_1_jugador";
        
    }
   
    update(deltaTime: number) {
        
    }
}


