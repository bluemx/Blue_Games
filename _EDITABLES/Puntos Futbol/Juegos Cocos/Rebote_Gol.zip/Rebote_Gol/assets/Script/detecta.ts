import { _decorator, Component, sys, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('detecta')
export class detecta extends Component {
    @property(Node)
    public pc: Node = null;
    @property(Node)
    public cel : Node = null;
    protected onLoad(): void {

        if (sys.platform === sys.Platform.DESKTOP_BROWSER) {
            console.log("Está en un navegador de escritorio");
            this.pc.active = true;
            this.cel.active = false;
        } else if (sys.platform === sys.Platform.MOBILE_BROWSER) {
            console.log("Está en un navegador móvil");
            this.cel.active = true;
            this.pc.active = false;
        } 
}
    start() {

    }

    update(deltaTime: number) {
        
    }
}


