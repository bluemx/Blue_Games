import { _decorator, Component, RigidBody2D, Vec2 } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('AutoImpulsoSiSeDetiene')
export class AutoImpulsoSiSeDetiene extends Component {
  @property(RigidBody2D)
  rb: RigidBody2D | null = null;

  /** Velocidad mínima considerada "en movimiento" (m/s aprox. física 2D) */
  @property
  minSpeed = 0.25;

  /** Tiempo que debe estar por debajo de minSpeed para considerarse "quieta" */
  @property
  minQuietTime = 0.6;

  /** Cada cuánto se verifica (segundos) */
  @property
  checkInterval = 0.1;

  /** Magnitud del impulso a aplicar (prueba 0.5–3.0) */
  @property
  impulseStrength = 1.2;

  /** Preferir impulsar en la última dirección de movimiento */
  @property
  preferLastDirection = true;

  /** Si no hay dirección previa, permitir dirección aleatoria completa */
  @property
  allowRandomKick = true;

  /** Usar fuerza en vez de impulso (más gradual) */
  @property
  useForceInsteadOfImpulse = false;

  /** (Opcional) fija una velocidad objetivo tras el empujón (0 = desactivado) */
  @property
  targetSpeedAfterKick = 0; // ej. 2.0

  private _stillAccum = 0;
  private _lastDir = new Vec2(1, 0); // dirección por defecto
  private _timerId: number | null = null;
  private yapuedo : boolean = false;
  onLoad() {
    if (!this.rb) this.rb = this.getComponent(RigidBody2D);
  }

  start() {
    // Verificación periódica (más barato que hacerlo en update)
    this.scheduleOnce(function(){
        this.yapuedo = true;
    },3);
    
    this.schedule(this._tick, this.checkInterval);
   
    
  }

  onDestroy() {
    if (this._timerId !== null) this.unschedule(this._tick);
  }

  private _tick(dt: number) {
    if(this.yapuedo){
            if (!this.rb) return;

            const v = this.rb.linearVelocity;
            const speed  = v.length();

            // Guarda la última dirección válida
            if (speed > this.minSpeed ) {
                this._lastDir.set(v.x, v.y).normalize();
            }

            // Acumula tiempo "quieta" o resetea
            if (speed < this.minSpeed *.2) {
                this._stillAccum += this.checkInterval;
            } else {
                this._stillAccum = 0;
                return;
            }

            // ¿Lleva quieta el tiempo suficiente?
            if (this._stillAccum >= this.minQuietTime) {
                this._nudge();
                this._stillAccum = 0; // evita empujar en cada tick
            }
    }
    
  }

  private _nudge() {
    if (!this.rb) return;

    // Elige dirección
    let dir = new Vec2(this._lastDir.x, this._lastDir.y);
    if (!this.preferLastDirection || dir.length() < 1e-3) {
      if (!this.allowRandomKick) return;
      const a = Math.random() * Math.PI * 2;
      dir.set(Math.cos(a), Math.sin(a));
    }
    dir.normalize();

    // Aplica impulso o fuerza
    const vec = dir.multiplyScalar(this.impulseStrength);
    if (this.useForceInsteadOfImpulse) {
      // Empuje gradual (si se te queda pegada por fricción alta)
      // El 'true' despierta el cuerpo si estaba dormido
      this.rb.applyForceToCenter(vec, true);
    } else {
      // Golpecito instantáneo
      this.rb.applyLinearImpulseToCenter(vec, true);
    }

    // (Opcional) asegura una velocidad mínima tras el empujón
    if (this.targetSpeedAfterKick > 0) {
      const v = this.rb.linearVelocity;
      const sp = v.length();
      if (sp < this.targetSpeedAfterKick) {
        const needed = dir.multiplyScalar(this.targetSpeedAfterKick);
        this.rb.linearVelocity = needed;
      }
    }
  }
}
