import { _decorator, CCFloat, CCInteger, Component, Label, Node, ProgressBarComponent, RigidBody2D, Scene, Sprite, Vec2 } from 'cc';
import { ManagerSleccion } from './ManagerSeleccion';
import { SeleccionEquipo } from './SeleccionEquipo';
import { Equipos } from './Equipos';
import { ButtonMessage } from './ButtonMessage';
import { PCmove2D } from './PCmove';
import { MovimientoCubeta } from './MovimientoPlayer';
const { ccclass, property } = _decorator;

@ccclass('ManagerGame')
export class ManagerGame extends Component {

    @property(ManagerSleccion)
    public MS : ManagerSleccion = null;
    @property(Equipos)
    public SE : Equipos = null;
    @property([Node])
    public players : Node [] = []; 
    @property(CCFloat)
    public tiempo : number = 0;
    @property(Node)
    public Game ; Node = null;
    private gameover : boolean = false;
    private yapuede : boolean = false;
    @property(CCInteger)
    public scoreplayer : number = 0;
    @property(CCInteger)
    public score2 : number = 0;
    @property(Label)
    public tiempo1: Label = null;
    @property(Label)
    public tiempo2 : Label = null;
    @property(Label)
    public nombre1 : Label = null;
    @property(Label)
    public nombre2 : Label = null;
    @property(Label)
    public score1 : Label = null;
    @property(Label)
    public score2l : Label = null;
    @property(RigidBody2D)
    public balon : RigidBody2D = null;
    @property([Node])
    public numeros : Node [] = [];
    @property([Node])
    public mensajes : Node [] = [];
    @property(PCmove2D)
    public pcPlayer : PCmove2D = null;
    @property(MovimientoCubeta)
    public Player1 : MovimientoCubeta = null;
    @property(MovimientoCubeta)
    public Player2: MovimientoCubeta = null;

    protected onLoad(): void {
        this.MS = ManagerSleccion._instance;
        this.SE = Equipos._instance;
        this.Game.active = false;
       
        this.numeros[0].active =true;
        this.numeros[1].active = false;
        this.numeros[2].active = false;
        this.scheduleOnce(function(){
            this.numeros[0].active = false;
            this.numeros[1].active = true;
            this.scheduleOnce(function(){
                this.numeros[1].active = false;
                this.numeros[2].active = true;

                this.scheduleOnce(function(){
                    this.numeros[2].active = false;
                    this.gameover = false;
                    
                },1);
            },1);
        },1);

    }
    start() {
        this.iniciojuego();
        this.scheduleOnce(function(){
            this.yapuede = true;
        },3);
    }
    reloj(deltaTime : number){
        this.tiempo -= deltaTime;
        this.tiempo1.string = "0 : " + Math.floor(this.tiempo).toString();
        this.tiempo2.string = "0 : " + Math.floor(this.tiempo).toString();
        if(this.tiempo<10){
             this.tiempo1.string = "0 : 0" + Math.floor(this.tiempo).toString();
            this.tiempo2.string = "0 : 0" + Math.floor(this.tiempo).toString();
        }
        //console.log(this.tiempo);
        if(this.tiempo <=0){
             this.tiempo1.string = "0 : 00";
            this.tiempo2.string = "0 : 00";
            this.nombre1.string = this.SE.nameequipo1.toString();
            this.nombre2.string = this.SE.nameequipo2.toString();
            this.score1.string = this.scoreplayer.toString();
            this.score2l.string = this.score2.toString();
            this.gameover = true;
            this.Player1.onDestroy();
            this.Player2.onDestroy();
            this.pcPlayer.puedeComenzar = false;
            this.Game.active= true;
            const scene = this.MS.nameScene;
            if(scene == "Seleccion_1_jugador"){
                this.Game.getComponent(ButtonMessage).sendMessageToParent();
            }
            else{
                this.Game.getComponent(ButtonMessage).sendMessageToParent2();
            }
           
            this.balon.linearVelocity = new Vec2(0,0);
            this.balon.angularVelocity = 0;
            this.balon.node.active=false;
            if(this.scoreplayer == 0 && this.score2 == 0){
                this.mensajes[0].active = false;
                this.mensajes[1].active = true;
                this.mensajes[2].active = false;
                this.mensajes[3].active = true;
                return;
            }
            else if(this.scoreplayer > this.score2){
                this.mensajes[0].active = true;
                this.mensajes[1].active = true;
                this.mensajes[2].active = false;
                this.mensajes[3].active = false;
                return;
            }
            else {
                this.mensajes[0].active = false;
                this.mensajes[1].active = false;
                this.mensajes[2].active = true;
                this.mensajes[3].active = true;
                return;
            }
           
        }
    }
    iniciojuego(){
        
        this.players[0].getComponent(Sprite).spriteFrame = this.SE.EquipoPlayer[this.SE.posPlayer];
        const scene = this.MS.nameScene;
        switch(scene){
            case "Seleccion_1_jugador":
                this.players[1].getComponent(Sprite).spriteFrame = this.SE.EquipoPlayer[this.SE.posPc];

                this.players[0].active=true;
                this.players[1].active = true;
                this.players[2].active=false;

                break;
            case "Seleccion_2_jugador" :
                this.players[2].getComponent(Sprite).spriteFrame = this.SE.EquipoPlayer[this.SE.posPc];

                this.players[0].active=true;
                this.players[1].active = false;
                this.players[2].active=true;

                break;
        }
    }
    update(deltaTime: number) {
        if(!this.gameover && this.yapuede){
            this.reloj(deltaTime);
        }
        
    }
}


