import { _decorator, Component, Node, Input, EventTouch, Vec3, NodeEventType, KeyCode, input, AnimationClip, Animation, CCBoolean, CCInteger } from 'cc';


const { ccclass, property } = _decorator;

@ccclass('MovimientoCubeta')
export class MovimientoCubeta extends Component {
  

    @property public limiteIzq:number = -250;
    @property public limiteDer:number = 250;
   
    @property(Node) nodeImage: Node=null;
    public posY:Vec3;

    @property
    public speed: number = 500;
    @property(Vec3)
    public targetPosition: Vec3 = new Vec3();
    @property(Vec3)
    public moveDirection: Vec3 = new Vec3();
    @property(Vec3)
    public newPosition: Vec3 = new Vec3();

    @property public flechas:boolean=false;
    @property public touch:  boolean = false;
    @property(Vec3) public transf: Vec3 = null;
    @property(CCInteger)
    public minY : number = 0;
    @property(CCInteger)
    public maxY : number = 0;
    @property(CCInteger)
    public minX : number = 0;
    @property(CCInteger)
    public maxX : number = 0;
    private derecha:boolean;
    private izquierda:boolean;
    public YaEntre: boolean;

    @property public state: string = "otro";
    private prevMouseX: number = 0;
    private direction: number = 0;
    @property(CCBoolean)
    public choque: boolean=false;
   

    onLoad(){
        this.choque = false;
        this.derecha = false;
        this.izquierda = false;
        this.YaEntre=false;
        //this.anim= this.getComponent(Animaciones);
       // this.animation = this.node.getComponentInChildren(Animation)
        //this.anim.IDLE();
        this.posY=this.nodeImage.getWorldPosition();

       
      
       this.scheduleOnce(function(){
             this.nodeImage.on(Input.EventType.TOUCH_START,this.Touch,this)

        this.nodeImage.on(Input.EventType.TOUCH_END,this.Stop,this)
        this.nodeImage.on(Input.EventType.TOUCH_CANCEL,this.Stop,this)
       },3);
        
       
       
    }

    onDestroy() {
        // Desregistrar eventos al destruir el componente
        this.node.off(Node.EventType.TOUCH_MOVE, this.Touch, this);
        

    }

    Stop()
    {
        this.YaEntre = false;
        this.state="idle";
      
        
        this.suelta();
    }
   
    Touch()
    {
            this.nodeImage.on(Node.EventType.TOUCH_MOVE,(event:EventTouch)=>{
                this.touch=true;
                let loc=event.getUILocation();
                
                if(loc.x < this.minX ){
 
                    loc.x = this.minX;
                
                }
                if(loc.x > this.maxX){
                    loc.x=this.maxX;
                }
                if( loc.y < this.minY){
                    loc.y=this.minY;
                }
                if( loc.y > this.maxY){
                    loc.y=this.maxY;
                }
                this.nodeImage.setWorldPosition(new Vec3(loc.x, loc.y, 0));
            })

       
        
    }

    
   
    suelta(){
        this.transf=this.nodeImage.getPosition();
        this.targetPosition=this.transf;
        this.nodeImage.getPosition(this.transf);

       
    }
    mueve(deltaTime){
          
        
    }

   
    update(deltaTime:number)
    {
        
    }
}


