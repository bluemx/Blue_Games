import { _decorator, Component, Button } from 'cc';
import { ManagerGame } from './ManagerGame';
import { ManagerSleccion } from './ManagerSeleccion';

const { ccclass, property } = _decorator;

@ccclass('ButtonMessage')
export class ButtonMessage extends Component {
    @property(ManagerGame)
    public manScore : ManagerGame = null;
   

  

    sendMessageToParent() {
        
             const score = this.manScore.scoreplayer;
            window.parent?.postMessage({
        
                score: score
    
            }, '*');
        
    }
    sendMessageToParent2(){
         const score = this.manScore.scoreplayer + this.manScore.score2;
            window.parent?.postMessage({
        
                score: score
    
            }, '*');
    }
    sendMessageToExit() {
        window.parent?.postMessage({
            state: 'exit'
        }, '*');
    }
    sendMessageToRestart() {
        window.parent?.postMessage({
            state: 'reset'
        }, '*');
    }
    sendMessageToStart() {
        window.parent?.postMessage({
            state: 'start'
        }, '*');
    }
}