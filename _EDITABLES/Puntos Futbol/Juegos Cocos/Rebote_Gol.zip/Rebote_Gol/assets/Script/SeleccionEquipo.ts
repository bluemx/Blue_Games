import { _decorator, Component, Node, SpriteFrame, director, EventTouch, UITransform, Sprite, CCInteger, Button, CCString, randomRangeInt, color, Color, SpriteRenderer, AnimationClip, find } from 'cc';
import { Equipos } from './Equipos';
const { ccclass, property } = _decorator;

@ccclass('SeleccionEquipo')
export class SeleccionEquipo extends Component {
    public static _instance: SeleccionEquipo = null;
    @property(Node)
    public Fondo : Node = null;
    @property(Node)
    public Fondo2 : Node = null;
    @property(CCInteger)
    public posSeleccion : number = 0;
    @property(CCInteger)
    public posSeleccionPlayer : number = 0;
    @property(CCInteger)
    public posSeleccionPc : number = -1;
    public posAnterior : number  = 0;
    public posAnterior2 : number = 0;
    @property([SpriteFrame])
    public BanderasNoSeleccionadas : SpriteFrame [] = [];
    @property(SpriteFrame)
    public BanderaSeleccionada : SpriteFrame[] = [];
   
  
    
    @property([Node])
    public equipos : Node[] = [];
    @property([Node])
    public equipos2 : Node[] = [];
    @property(CCString)
    public equipoSeleccionado : String = "México";
    @property(CCString)
    public equipoSeleccionadoPC : String = "";
    @property(CCString)
    public name_Scene : String = "";
    @property(Equipos) 
    public ManagerEquipos : Equipos = null;


    protected onLoad(): void {
       
     this.ManagerEquipos = Equipos._instance;
     this.ManagerEquipos.posPc = -1;
        

    }
    start() {
        this.Fondo= find("Canvas/Fondo");
        this.Fondo2 = find("Canvas/Fondo2");
         

        this.equipos = [];
        this.equipos2 = [];
        
        
        
            for(let i = 0 ; i < 12; i++){
               const nodo1 = this.Fondo.children[0].children[i];
                const nodo2 = this.Fondo2.children[0].children[i];
                if (nodo1 && nodo2) {
                    this.equipos.push(nodo1);
                    this.equipos2.push(nodo2);
                }
            }
        
        
    }
    CambiaSeleccion(){
        if(this.posAnterior != this.posSeleccion){
        const boton = this.equipos[this.posAnterior].getComponent(Button);
            if (boton) {
                    boton.normalSprite = this.BanderasNoSeleccionadas[this.posAnterior];
            }
        }
        this.posAnterior = this.posSeleccion;
        this.equipos[this.posSeleccion].getComponent(Button).normalSprite = this.BanderaSeleccionada[this.posSeleccion];
        this.equipoSeleccionado = this.equipos[this.posSeleccion].name.toString();
        this.posSeleccionPlayer = this.posSeleccion;
        this.ManagerEquipos.posPlayer = this.posSeleccionPlayer;
        this.ManagerEquipos.nameequipo1 = this.equipoSeleccionado;

    }
     CambiaSeleccion2(){
        if(this.posAnterior2 != this.posSeleccion){
        const boton = this.equipos[this.posAnterior2].getComponent(Button);
            if (boton) {
                    boton.normalSprite = this.BanderasNoSeleccionadas[this.posAnterior2];
            }
        
        }  
        
        this.posAnterior2 = this.posSeleccion;
        this.equipos2[this.posSeleccion].getComponent(Button).normalSprite = this.BanderaSeleccionada[this.posSeleccion];
        this.equipoSeleccionado = this.equipos[this.posSeleccion].name.toString();
        this.posSeleccionPc = this.posSeleccion;
        this.ManagerEquipos.posPc = this.posSeleccionPc;
        this.ManagerEquipos.nameequipo2 = this.equipoSeleccionado;

    }
     CambiaJugador2(){
        this.Fondo.active=false;
        this.Fondo2.active=true;
        console.log("Cambia el color del equipo seleccionado");
        this.equipos2[this.posSeleccionPlayer].getComponent(Sprite).color= new Color(160,160,160);
        this.equipos2[this.posSeleccionPlayer].getComponent(Button).interactable = false;

        

       
        
    }
    CambiaJugadorPC(){
        this.equipoSeleccionado = this.equipos[this.posSeleccion].name.toString();
        this.ManagerEquipos.posPlayer = this.posSeleccionPlayer;
        this.ManagerEquipos.nameequipo1 = this.equipoSeleccionado;
        this.Fondo.active=false;
        this.Fondo2.active=true;
       
        this.equipos2[this.posSeleccion].getComponent(Sprite).color= new Color(160,160,160);


        

        this.scheduleOnce(function(){
            let random = randomRangeInt(0,9);
            if(random == this.posSeleccion){
                random+=1;
                if(random >= 9){
                    random = 0;
                }
            }
            this.posSeleccion = random;
            this.equipos2[this.posSeleccion].getComponent(Sprite).spriteFrame = this.BanderaSeleccionada[this.posSeleccion];
            this.equipoSeleccionadoPC = this.equipos[this.posSeleccion].name.toString();
            this.posSeleccionPc = this.posSeleccion;
            this.ManagerEquipos.posPc = this.posSeleccionPc;
            this.ManagerEquipos.nameequipo2 = this.equipoSeleccionadoPC;
        },3)
        
    }
    update(deltaTime: number) {
        
    }
}


