import {
  _decorator,
  Component,
  RigidBody2D,
  Collider2D,
  Contact2DType,
  IPhysics2DContact,
  Vec2,
  CCInteger,
  randomRangeInt,
  Vec3,
  CircleCollider2D,
  randomRange
} from 'cc';
import { ManagerGame } from './ManagerGame';
const { ccclass, property } = _decorator;

@ccclass('InicioPelota')
export class InicioPelota extends Component {
  @property(RigidBody2D)
  body: RigidBody2D;
  @property(Vec2)
  private vecInicio : Vec2 = new Vec2(0,0);
  @property(CCInteger)
  public speed : number = 0;
  @property(Collider2D)
  private colision : Collider2D = null;
  @property(ManagerGame)
  public manager : ManagerGame = null;
  @property(Vec2)
  public vectorgolpe : Vec2 = new Vec2(0,0);

    

  onLoad() {
     this.colision = this.getComponent(Collider2D);
    this.colision.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
    //console.log("inicia collider");
    this.body =  this.getComponent(RigidBody2D);
   
  }

  start() {
    this.scheduleOnce(function(){
      this.primerimpulso();
      
    },3)    
    
    }
    primerimpulso(){
      
        let x = randomRange(-1,0);
        let y = randomRange(-1,0);
        if(x == 0){
          x = 25 * this.speed;
        y = 25 *this.speed;
        }
        else{
          x = -25 * this.speed;
          y = -25 *this.speed;
        }
       
        this.vecInicio = new Vec2(x,y);
     
  
       this.body.applyLinearImpulseToCenter(this.vecInicio,true);
    }

  public onBeginContact( selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null ) {
    
    //console.log(otherCollider.group);

    const pared =otherCollider.node.name;
     if (!contact) return;

    const v = this.body.linearVelocity.clone(); // velocidad actual
    if (v.length() < 1e-4) return;

    const wm = contact.getWorldManifold();
    const n = wm.normal.clone(); // normal del contacto (Vec2)
    if (n.length() < 1e-4) return;
    n.normalize();

    const dot = v.dot(n);
    // r = v - 2*(v·n)*n
    const r = v.subtract(n.multiplyScalar(2 * dot));

    // conservar la misma rapidez
    const speed = this.body.linearVelocity.length();
    if (r.length() > 1e-4) {
      r.normalize().multiplyScalar(speed);
      this.body.linearVelocity = r;
    } else {
      // caso degenerado: invertir
      this.body.linearVelocity = new Vec2(-v.x, -v.y);
    }
    switch(pared){
      case "Player":
        const fuerzax = randomRangeInt(-50,50);
        const fuerza = randomRangeInt(20,50);
        this.body.applyLinearImpulseToCenter(new Vec2(this.body.linearVelocity.x  ,this.body.linearVelocity.y + fuerza),true);
        
      break;
      case "PC":
        const fuerzapc = randomRangeInt(-20,-50);
       this.body.applyLinearImpulseToCenter(new Vec2(this.body.linearVelocity.x, - this.body.linearVelocity.y + fuerzapc),true);
       
      break;
     case "trigger":
      this.manager.scoreplayer++;
      this.body.linearVelocity = new Vec2(0,0);
      this.body.angularVelocity = 0;
      this.resetaeBalon();
      break;
      case "triggerPC":
        this.manager.score2++;
        this.body.linearVelocity = new Vec2(0,0);
      this.body.angularVelocity = 0;
      this.resetaeBalon();
      break;
   
    }
   
    
    
  }
  resetaeBalon(){
    this.scheduleOnce(function(){
      this.node.setPosition(new Vec3(0,11,0));
      this.primerimpulso();
    },1);
            
    }
    update(deltaTime: number) {
    
    const maxSpeed = 30;

    const velocity = this.body.linearVelocity;

    const speed = velocity.length();

    if (speed > maxSpeed) {
        velocity.normalize();
        velocity.multiplyScalar(maxSpeed);
        this.body.linearVelocity = velocity;
    }
    }
}
