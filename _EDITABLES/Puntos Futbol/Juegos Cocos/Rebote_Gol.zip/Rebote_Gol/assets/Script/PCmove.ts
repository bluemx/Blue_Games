// PCmove2D.ts
import { _decorator, Component, Node, math, CCFloat } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('PCmove')
export class PCmove2D extends Component {
  @property({ type: Node, tooltip: 'Referencia al nodo de la pelota' })
  public puck: Node = null;

  @property({ type: CCFloat, tooltip: 'Velocidad de seguimiento' })
  public speed = 5;

  @property({ type: CCFloat, tooltip: 'Límite mínimo en X' })
  public xMin = -300;
  @property({ type: CCFloat, tooltip: 'Límite máximo en X' })
  public xMax =  300;

  @property({ type: CCFloat, tooltip: 'Límite mínimo en Y' })
  public yMin = 300;
  @property({ type: CCFloat, tooltip: 'Límite máximo en Y' })
  public yMax =  320;

  // Si quieres error separado en cada eje
  private errorX = 0;
  private errorY = 0;
  private timer = 0;
  private interval = 0.5;
  public puedeComenzar : boolean = false;
  protected onLoad(): void {
    this.scheduleOnce(function(){
      this.puedeComenzar = true;
    },3);
  }
  termino(){
    this.puedeComenzar = false;
  }
  update(dt: number) {
    if(this.puedeComenzar){
        if (!this.puck) return;

    // Recalcular errores cada interval segundos
    this.timer += dt;
    if (this.timer >= this.interval) {
      this.errorX = math.lerp(-100, 100, Math.random());
      this.errorY = math.lerp(-300,300,Math.random());
      this.timer = 0;
    }

    const curr = this.node.position;
    const target = this.puck.position;

    // Cálculo de la nueva X y nueva Y
    const newX = math.clamp(
      math.lerp(curr.x, target.x - this.errorX, this.speed * dt),
      this.xMin, this.xMax
    );
    const newy = math.clamp(
      math.lerp(curr.y, (target.y + 150) - this.errorY, this.speed * dt),
      this.yMin, this.yMax
    );

    // Mover en X e Y; Z queda igual
    this.node.setPosition(newX, newy, curr.z);
    }
    
  }
}
