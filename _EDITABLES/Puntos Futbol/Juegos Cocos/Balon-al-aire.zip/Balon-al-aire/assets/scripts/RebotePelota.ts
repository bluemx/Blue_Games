import { _decorator, Component, Node, Input, Collider2D, Vec3, Vec2, EventTouch, RigidBody2D, randomRange, CCFloat, Label, CCInteger, SpriteFrame, Sprite, spriteAssembler, color, Prefab, instantiate } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('RebotePelota')
export class RebotePelota extends Component {
    @property(Label)
    public score : Label = null;
    @property(Node)
    public nodeImage : Node = null;
    @property(RigidBody2D)
    public RigidBody : RigidBody2D = null;
    @property
    jumpDuration: number = 0.2; // Duración del salto

    private impulseX:number = 0;
    @property(CCFloat)
    private impulseY:number = 0;

    @property(CCInteger)
    private ValorRebote : number = 0;

    @property(CCFloat)
    private x : number = 600;
    @property(CCFloat)
    private y : number = 700;
    public NewPosition : Vec3 = new Vec3;
    public ScoreText : number = 0;

    @property(SpriteFrame)
    public BalonBrilla : SpriteFrame = null;
    @property(SpriteFrame)
    public balon : SpriteFrame = null;
    @property(Prefab)
    public brilloParticulas : Prefab = null;

    protected onLoad(): void {
        
        this.nodeImage = this.node;
        this.RigidBody= this.getComponent(RigidBody2D)
        let collider = this.getComponent(Collider2D);
        this.nodeImage.on(Input.EventType.TOUCH_START,this.Touch,this)

        /*window.parent.postMessage(
            {
                state: "juego"
            },
            "*"
        );*/
    }
    start() {

    }
    multiplocinco(numero : number){
        if(numero % 5 == 0){
            this.getComponent(Sprite).spriteFrame = this.BalonBrilla;
            this.getComponent(Sprite).color = color(255,246,138);
            let node = instantiate(this.brilloParticulas);
            node.setParent(this.node);
        }
        else{
            this.getComponent(Sprite).spriteFrame = this.balon;
            this.getComponent(Sprite).color = color(255,255,255);
        }
    }

    Touch()
    {
        console.log("saltaaaa");
        this.ScoreText +=this.ValorRebote;
        this.multiplocinco(this.ScoreText)
        this.score.string = this.ScoreText.toString();
        this.impulseX = randomRange(-500,500);
        
        this.impulseY = randomRange(this.x,this.y);

        /*if(this.impulseY < 0)
            {
                this.impulseY = (this.RigidBody.linearVelocity.y * -10) * 2;
            }
            else{
                this.impulseY = this.RigidBody.linearVelocity.y * 3 ;
            }
        */
        this.RigidBody.applyLinearImpulseToCenter(new Vec2(this.impulseX,this.impulseY),true);
        this.x += 5;
        this.y += 5;
            
       
      
    }
    

    update(deltaTime: number) {
        
    }
}


