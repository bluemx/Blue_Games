import { _decorator, Component, Node, director, Contact2DType, find, Collider2D, Label, Collider, Sprite, ParticleSystem2D, Prefab, instantiate, Vec3,  } from 'cc';
import { ButtonMessage } from './ButtonMessage';
import { RebotePelota } from './RebotePelota';
const { ccclass, property } = _decorator;

@ccclass('GameOver')
export class GameOver extends Component {
    @property(Node)
    public GameOver:Node = null;
    @property(Label)
    public scoreFinal: Label = null;
    @property(Prefab)
    public sistemaParticulas : Prefab  = null;
    @property(Label)
    public scoreGame : Label = null;
    @property(ButtonMessage) public a: ButtonMessage=null;

    @property(Node)
    public balon : Node = null;
    @property([Node])
    public mensajes : Node [] = [];
     onLoad(): void {
        director.resume();
        
        let collider = this.getComponent(Collider2D);
        if (collider){
        collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
        }
    }
    start() {

        this.GameOver= find("Canvas/GameOverFondo");
        
        this.GameOver.active=false;
        

    }

    onBeginContact(selfCollider: Collider2D, otherCollider: Collider2D) {
      console.log(otherCollider.group);
        if(otherCollider.group == 2){
            
            this.GameOver.active=true;
            const score = this.balon.getComponent(RebotePelota).ScoreText;
            if(score < 10){
                this.mensajes[0].active = false;
                this.mensajes[1].active = true;
            }
            else{
                this.mensajes[0].active = true;
                this.mensajes[1].active = false;


            }
            this.a.sendMessageToParent();
            const node = instantiate(this.sistemaParticulas);
            node.setParent(this.GameOver);
            this.scoreFinal.string = this.scoreGame.string;
           // director.pause();
           /* window.parent.postMessage(
                {
                    state: "gameover",
                    score: this.scoreGame.string
                },
                "*"
            );
            */
        }
              
        console.log(otherCollider.group, otherCollider.name, otherCollider.tag);
        
    }


}


