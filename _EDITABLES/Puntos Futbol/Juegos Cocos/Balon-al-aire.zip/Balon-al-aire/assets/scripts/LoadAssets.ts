import {
  _decorator,
  Component,
  Node,
  assetManager,
  Texture2D,
  SpriteFrame,
  Sprite,
  ImageAsset,
} from "cc";
const { ccclass, property } = _decorator;

@ccclass("LoadAssets")
export class LoadAssets extends Component {
  @property replaceby: string = "";

  start() {
    // Define the message listener function
    const handleMessage = (event: MessageEvent): void => {
      const data = event.data;

      if (data.state === "data") {
        for (const key in data.img) {
          if (data.img.hasOwnProperty(key)) {
            window["img"] = window["img"] || {};
            window["img"][key] = data.img[key];
          }
        }

        for (const key in data.info) {
          if (data.info.hasOwnProperty(key)) {
            window["info"] = window["info"] || {};
            window["info"][key] = data.info[key];
          }
        }

        // Call function to load texture
        this.loadTexture();
      }
    };

    // Remove any existing message listeners
    window.removeEventListener("message", handleMessage);

    // Add the message listener
    window.addEventListener("message", handleMessage);

    // Call function to load texture during initial execution
    this.loadTexture();
  }

  loadTexture() {
    // Check if the value in replaceby exists in window.img and load the texture
    if (window["img"] && window["img"][this.replaceby]) {
      console.log("replaceby:", window["img"][this.replaceby]);

      assetManager.loadRemote(
        window["img"][this.replaceby],
        ImageAsset,
        (err, imageAsset: ImageAsset) => {
          if (err) {
            console.error("Failed to load image:", err);
            return;
          }

          const texture = new Texture2D();
          texture.image = imageAsset;

          const newSpriteFrame = new SpriteFrame();
          newSpriteFrame.texture = texture;

          const sprite = this.node.getComponent(Sprite);
          if (!sprite) {
            console.error("Node does not have a Sprite component.");
            return;
          }
          sprite.spriteFrame = newSpriteFrame;
        },
      );
    }
  }

  update(deltaTime: number) {}
}
