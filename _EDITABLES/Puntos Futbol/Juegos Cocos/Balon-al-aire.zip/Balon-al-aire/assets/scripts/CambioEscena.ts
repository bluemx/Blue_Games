import { _decorator, CCString, Component, director, SceneAsset } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('CambioEscena')
export class CambioEscena extends Component {
    @property(CCString)
    public name2 : string = "";
    onLoad() {
        // Agrega un evento de clic al botón
        this.cambio();
       
    }

    //cc.director.preloadScene("table", function () {
    //    cc.log("Next scene preloaded");
    //});
    cambio() {
       
        var progress = 0;
            director.preloadScene(this.name2.toString(), (completedCount: number, totalCount: number, item: any) => {
            progress = completedCount / totalCount;
            }, (error: Error, asset: SceneAsset) => {
                //do something after preloaded scene
        
            });
       
    }
    Carga(){
        director.loadScene(this.name2.toString());
    }
}


