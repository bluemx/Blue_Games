import { _decorator, animation, Component, Node, Label,ITriggerEvent, Collider, Vec3, Animation, randomRangeInt, RigidBody, instantiate, Prefab } from 'cc';
import { arrastrededo } from './arrastrededo';
import { ManagerScore } from './ManagerScore';
import { Golazo } from './Golazo';
const { ccclass, property } = _decorator;

@ccclass('Portero')
export class Portero extends Component {
        @property(Label)
        public score : Label = null;
        @property(Label)
        public ScoreFinal : Label = null;
        @property(Node)
        public bienHecho : Node = null;
        @property(Prefab)
        public particulas : Prefab = null;
        @property(Node)
        public Canvas : Node = null;
        
        @property(Node)
        public managerScore : Node = null;
        @property(Node)
        public gol : Node = null;
        private scoreText : number = 0;
        private _scalingTime: number = 0;
        private _scalingActive: boolean = false;
        @property
        scaleDuration: number = 4.0; // Tiempo en segundos para el cambio de escala
        @property(Vec3)
        initialScale: Vec3 = new Vec3(.4, .4, .4);
   
        @property(Vec3)
        targetScale: Vec3 = new Vec3(1, 1, 1);




       protected onLoad(): void {
        this.bienHecho.active= false;
        const collider = this.getComponent(Collider);
        if (collider) {
            // Suscribirse a los eventos de trigger
            
            
        }
    }
   
    actualizascore(){
        this.scheduleOnce(function(){
            if(!this.gol.getComponent(Golazo).haygol){
                this.bienHecho.active=true;
                this.gol.getComponent(Golazo).goles = 0;
              const node = instantiate(this.particulas);
              node.setParent(this.Canvas);
              
              this.scheduleOnce(function(){
                this.bienHecho.active=false;
                this.managerScore.getComponent(ManagerScore).score+=10;
                this.score.string = this.managerScore.getComponent(ManagerScore).score.toString();
                this.ScoreFinal.string=this.score.string;
                
              },3);
            }
        },1.5);
   
        
    }
    start() {
        

    }

    update(deltaTime: number) {

       
        
    }
}


