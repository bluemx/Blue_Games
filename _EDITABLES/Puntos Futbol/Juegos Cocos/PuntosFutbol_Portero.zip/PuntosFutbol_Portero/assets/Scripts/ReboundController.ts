// En tu componente del Canvas UI
import { _decorator, CCBoolean, Component, Node, RigidBody, Sprite, SpriteFrame, SpriteRenderer, Vec3 } from 'cc';
import { Portero } from './Portero';
const { ccclass, property } = _decorator;

@ccclass('ReboundController')
export class ReboundController extends Component {

    @property(Node)
    ballNode: Node = null;
    @property([SpriteFrame])
    public guantesSprite : SpriteFrame[] = [];
    @property(Node)
    public portero : Node = null;

    @property(CCBoolean)
    public puedeDetener : boolean = false;
    @property(CCBoolean)
    public yaDetuvo : boolean = false;
    @property(Vec3)
    public inicioPortero : Vec3 = new Vec3(0,0,0);
    @property
    reboundMultiplier: number = 2; // Cuánto más fuerte el rebote

    @property([SpriteFrame])
    public cursor : SpriteFrame[] = [];

    protected onLoad(): void {
       this.portero.getComponent(SpriteRenderer).spriteFrame = this.guantesSprite[0];
        //this.node.on(Node.EventType.TOUCH_START, this.onTouch, this);
        this.node.on(Node.EventType.TOUCH_START, this.onTouch, this)
        this.node.on(Node.EventType.TOUCH_END, this.onTouchCancel, this)
        this.NoPuedeDetener();
    }
    YaPuedeDetener(){
        this.node.getComponent(Sprite).spriteFrame = this.cursor[1];
        this.puedeDetener = true;
    }
    NoPuedeDetener(){
        this.node.getComponent(Sprite).spriteFrame = this.cursor[0];
        this.puedeDetener = false;
    }
    onTouch(EventType:Touch){
        if(this.puedeDetener){
            if(!this.yaDetuvo){
                this.portero.setWorldPosition(new Vec3(this.portero.position.x, this.ballNode.position.y, this.portero.position.z))
                this.portero.getComponent(SpriteRenderer).spriteFrame=this.guantesSprite[1];
                this.portero.getComponent(Portero).actualizascore();
                if (!this.ballNode) return;

                const rb = this.ballNode.getComponent(RigidBody);
                if (!rb) return;

                const velocity = new Vec3();
                rb.getLinearVelocity(velocity);

                if (velocity.length() == 0) return; // No rebotar si no se mueve

                // Dirección contraria normalizada
                const oppositeDir = velocity.clone().normalize().multiplyScalar(-.7);

                // Fuerza más fuerte que la velocidad actual
                const force = oppositeDir.multiplyScalar(velocity.length() * this.reboundMultiplier);

                rb.applyImpulse(force, new Vec3(0, 0, 0)); // Aplicar en el centro de masa
                this.yaDetuvo = true;
                this.scheduleOnce(function(){
                    this.portero.setWorldPosition(this.inicioPortero);
                },.5)
            }
            
        }
        

    }

    onTouchCancel(EventType:Touch){
        this.portero.getComponent(SpriteRenderer).spriteFrame=this.guantesSprite[0];
       

    }
    onButtonClick() {
       
    }
}
