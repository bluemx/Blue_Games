import { _decorator, Component, Node, Vec3, EventTouch, Camera } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('GuantesPortero')
export class TouchMoveObject extends Component {
    @property(Node)
    canvas: Node = null; // Referencia al Canvas (UI)

    @property(Node)
    myObject: Node = null; // Objeto que queremos mover en el mundo
    

    @property(Camera)
    myCamera: Camera = null; // La cámara principal

    // Factor de interpolación (lerpFactor) para suavizar el movimiento
    @property
    lerpFactor: number = 1;

    // Offsets para ajustar el rango de movimiento en cada eje.
    // Por ejemplo: si offsetX es 0.5 y offsetY es 1.5, el objeto se moverá menos en X y más en Y.
    @property
    offsetX: number = 1.0;

    @property
    offsetY: number = 500.0;

    onLoad() {
        this.node.on(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
       
    }

    onTouchMove(event: EventTouch) {
        // 1. Obtener la posición del toque en pantalla
        const touchPos = event.getLocation();
        
        // 2. Convertir la posición de pantalla a posición en el mundo (se asume z = 0)
        const worldTouchPos = this.myCamera.screenToWorld(new Vec3(touchPos.x, touchPos.y, 0));
        
        // 3. Obtener la posición actual del objeto
        const currentPos = this.myObject.worldPosition;
        
        // 4. Calcular la diferencia (delta) entre el toque y la posición actual
        const delta = new Vec3(
            worldTouchPos.x - currentPos.x,
            worldTouchPos.y - currentPos.y,
            0
        );
        
        // 5. Aplicar el offset de forma independiente a cada eje
        const adjustedDelta = new Vec3(delta.x * this.offsetX, delta.y * this.offsetY, 0);
        
        // 6. Calcular la posición destino a la que se quiere mover el objeto
        const targetPos = new Vec3(
            currentPos.x + adjustedDelta.x,
            currentPos.y + adjustedDelta.y,
            currentPos.z // Mantener la Z original
        );
        
        // 7. Interpolar suavemente desde la posición actual a la posición destino
        const newPos = new Vec3();
        //Vec3.lerp(newPos, currentPos, targetPos, this.lerpFactor);
        
        // 8. Actualizar la posición del objeto
        this.myObject.setWorldPosition(targetPos);
    }
}
