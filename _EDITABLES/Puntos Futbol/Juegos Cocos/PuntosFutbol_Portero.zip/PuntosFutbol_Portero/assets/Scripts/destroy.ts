import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('destroy')
export class destroy extends Component {
    protected onLoad(): void {
        this.scheduleOnce(function(){
            this.node.active=false;
            this.node.destroy();
        },20)
    }
    start() {

    }

    update(deltaTime: number) {
        
    }
}


