import { _decorator, Component, Node, CCInteger } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('Instrucciones')
export class Instrucciones extends Component 
{
    @property (Node) inst=null;
    /*@property (Node) inst01=null;
    @property (Node) inst02=null;*/

    @property([Node]) insts:Node[]= [];
    @property(CCInteger) index:number=0;
    @property([Node]) flechas:Node[]=[];

    protected onLoad(): void 
    {
        this.inst.active=true;//primera instruccion
        /*this.inst01.active=false;
        this.inst02.active=false;*/

        this.Inicio();
    }

    start() {

    }

    update(deltaTime: number) {
        
    }

    inicioInstruccion()//boton siguiente primera inst
    {
        this.inst.active=false;
        //this.inst01.active=true;
        this.Cambio();
        
    }

    Cambio()
    {
        this.insts[this.index].active=true;
        if(this.index==0)
        {   
            this.flechas[1].active=true;
            this.flechas[0].active=false;
        }
        else if(this.index>0&&this.index<this.insts.length-1)
        {    
            this.flechas[0].active=true;
            this.flechas[1].active=true;
        }
        else if(this.index==this.insts.length-1)
            {    
                this.flechas[0].active=true; 
                this.flechas[1].active=false;
            }
    }

    Next()
    {
        /*this.inst01.active=false;
        this.inst02.active=true;*/
        if(this.index>=0&&this.index<this.insts.length-1)
        {
            this.insts[this.index].active=false;

            this.index++;
            
            this.Cambio();
            
        }
        
        
        
    }

    Back()
    {
        /*this.inst01.active=true;
        this.inst02.active=false;*/
        if(this.index<=this.insts.length-1&&this.index>0)
            {
                this.insts[this.index].active=false;
                this.index--;
                this.Cambio();
                
            }

    }

    Inicio()
    {
        for(let i=0;i<this.insts.length;i++)
        {
            this.insts[i].active=false;
        }
    }
}
