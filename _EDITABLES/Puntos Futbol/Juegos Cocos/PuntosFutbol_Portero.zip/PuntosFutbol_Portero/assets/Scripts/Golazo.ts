import { _decorator, Component, Node, Collider, ITriggerEvent, Label, Prefab, instantiate, RigidBody, CCBoolean, Button } from 'cc';
import { KickBall } from './KickBall';
import { ButtonMessage } from './ButtonMessage';
const { ccclass, property } = _decorator;

@ccclass('Golazo')
export class Golazo extends Component {

    @property(Node)
    public AnimGol : Node = null;
    @property(Label)
    public score : Label = null;
    @property(Label)
    public ScoreFinal : Label = null;
    private scoreText : number = 0;
    @property(CCBoolean)
    public haygol : boolean = false;
    @property(Node)
    public gameOver : Node = null;
    public goles : number = null;
    @property(Node)
    public canvas : Node = null;
    @property(Node)
    public ball : Node = null;
    @property(ButtonMessage)
    public boton : ButtonMessage = null;

    protected onLoad(): void {
        this.AnimGol.active=false;
        this.gameOver.active = false;
        const collider = this.getComponent(Collider);
        if (collider) {
            // Suscribirse a los eventos de trigger
            collider.on('onTriggerEnter', this.onTriggerEnter, this);
        }
    }
    onTriggerEnter(event: ITriggerEvent ){

        const otherCollider = event.otherCollider;

        console.log(otherCollider.getGroup());
        if(otherCollider.getGroup()==4){
            this.haygol = true;
            this.goles +=1;
            otherCollider.getComponent(RigidBody).clearVelocity();
            otherCollider.getComponent(Collider).enabled= false;
            this.AnimGol.active=true;
            this.scheduleOnce(function(){
                this.AnimGol.active=false;
                if(this.goles >=2){
                    this.gameOver.active=true;
                    this.boton.sendMessageToParent();
                    this.ball.getComponent(KickBall).game=true;
                }
                

            },1.5);

            
        }

    }
    start() {

    }

    update(deltaTime: number) {
        
    }
}


