import { _decorator, Component, Node, Vec3, RigidBody, CCInteger, ITriggerEvent, randomRangeInt, CCFloat, Collider, randomRange } from 'cc';
import { Golazo } from './Golazo';
import { ReboundController } from './ReboundController';
const { ccclass, property } = _decorator;

@ccclass('KickBall')
export class KickBall extends Component {
    @property(Node)
    ball: Node = null; // El balón

    @property(Vec3)
    public posInicial: Vec3 = new Vec3(0, 0, 0);

    @property([Node])
    public goal: Node[] = []; // La portería (o un punto representativo de ella)

    @property(Node)
    public posiciones: Node = null

    @property(CCInteger)
    public pos: number = 0;

    // Magnitud total de la fuerza que se desea aplicar
    @property(CCFloat)
    private kickForce: number = 500;

    // Ángulo de la patada en grados (determina el arco)
    @property
    kickAngle: number = 45;

    // Duración en segundos durante la cual se aplicará la fuerza
    @property
    kickDuration: number = 0.3;

    // Parámetros para la escala
    @property
    scaleDuration: number = 2.0; // Tiempo en segundos para el cambio de escala

    // Escala inicial (cuando el balón es "cercano") y escala final (cuando se aleja)
    @property(Vec3)
    initialScale: Vec3 = new Vec3(1, 1, 1);

    @property(Vec3)
    targetScale: Vec3 = new Vec3(0.3, 0.3, 0.3);
    
    public game : boolean = false;

    @property(Node)
    public gol : Node = null;
    // Variables internas para la patada
    private _kickTimeRemaining: number = 0;
    private _forceVector: Vec3 = new Vec3();

    // Variables internas para el escalado al patear
    private _scalingTimeKick: number = 0;
    private _scalingActiveKick: boolean = false;

    // Variables internas para el escalado al rebotar
    private _scalingTimeBounce: number = 0;
    private _scalingActiveBounce: boolean = false;

    @property(Node)
    public Dedo:Node = null;
    protected onLoad(): void {
       
        const collider = this.getComponent(Collider);
        if (collider) {
            collider.on('onCollisionEnter', this.onCollisionEnter, this);
            collider.on('onTriggerEnter', this.onTriggerCollisionEnter,this);
            //collider.on('onTriggerStay',this.onTriggerCollisionEnter,this);
            collider.on('onTriggerExit', this.onTriggerCollisionExit,this);
        }
    }

    onCollisionEnter(event: ITriggerEvent) {
        const otherCollider = event.otherCollider;
        //console.log(otherCollider.getGroup() + " " + otherCollider.name);

       
        if (otherCollider.getGroup() == 2 || otherCollider.getGroup() == 8) {
            // Reiniciar el contador del escalado por rebote y activar el efecto
            this._scalingTimeBounce = 0;
            this._scalingActiveBounce = true;
        }
    }
    onTriggerCollisionEnter(event: ITriggerEvent){
        const otherCollider = event.otherCollider;
        console.log("Entro al trigger " + otherCollider.getGroup() + " " + otherCollider.name);
        this.Dedo.getComponent(ReboundController).YaPuedeDetener();

    }
    onTriggerCollisionExit(event: ITriggerEvent){
        const otherCollider = event.otherCollider;
        console.log("Salio del trigger "+otherCollider.getGroup() + " " + otherCollider.name);
        this.Dedo.getComponent(ReboundController).NoPuedeDetener();
    }
    // Este método inicia la patada y resetea el efecto de escalado de patada
    kick() {
        if(!this.game){
            
            // Reiniciar el contador de escalado para la patada
            this._scalingTimeKick = 0;
            this._scalingActiveKick = true;
            // Establecer la escala inicial del balón
            this.ball.setScale(this.initialScale);

            // Obtener la posición del balón y la posición destino
            const ballPos = this.ball.worldPosition;
            const goalPos = this.posiciones.worldPosition;

            // Calcular la dirección horizontal (plano XZ)
            const direction = new Vec3(goalPos.x - ballPos.x, 0, goalPos.z - ballPos.z);
            direction.normalize();

            // Ajustar aleatoriamente el ángulo y la fuerza
            this.kickAngle = randomRange(26.5, 27);
            const angleRad = this.kickAngle * (Math.PI / 180);
            this.kickForce = randomRange(1225, 1250);

            // Calcular las componentes de la fuerza
            const horizontalForce = this.kickForce * Math.cos(angleRad);
            const verticalForce = this.kickForce * Math.sin(angleRad);

            // Vector total de fuerza
            this._forceVector = new Vec3(
            direction.x * horizontalForce,
            verticalForce,
            direction.z * horizontalForce
        );

        // Reiniciar el tiempo durante el cual se aplicará la fuerza
        this._kickTimeRemaining = this.kickDuration;

        // Después de 8 segundos, reiniciamos el balón para el siguiente tiro
        this.scheduleOnce(function () {
            console.log("reinicia");
            this.Dedo.getComponent(ReboundController).yaDetuvo = false;
            this.gol.getComponent(Golazo).haygol=false;
            const rb: RigidBody = this.ball.getComponent(RigidBody);
            // Resetear posición y escala del balón
            this.ball.setWorldPosition(this.posInicial);
            this.ball.setScale(new Vec3(1, 1, 1));
            this.ball.getComponent(Collider).enabled = true;
            rb.clearVelocity();
            rb.setAngularVelocity(Vec3.ZERO);
            
            
                // Llamar de nuevo a kick() después de 5 segundos para el siguiente tiro
            this.scheduleOnce(function () {
                this.kick();
            }, 5);
                      
            
        }, 8);
        }
        
        
    }

    update(deltaTime: number) {
        // Aplicar fuerza de forma gradual para suavizar la patada
        if (this._kickTimeRemaining > 0) {
            const rb = this.ball.getComponent(RigidBody);
            if (rb) {
                const frameForce = new Vec3(
                    this._forceVector.x * (deltaTime / this.kickDuration),
                    this._forceVector.y * (deltaTime / this.kickDuration),
                    this._forceVector.z * (deltaTime / this.kickDuration)
                );
                rb.applyForce(frameForce, new Vec3(0, 0, 0));
                const angular = randomRange(-15, 15);
                rb.setAngularVelocity(new Vec3(0, angular, 0));
            }
            this._kickTimeRemaining -= deltaTime;
        }

        // Actualizar la escala para la patada (efecto de lejanía)
       /* if (this._scalingActiveKick) {
            this._scalingTimeKick += deltaTime;
            const t = Math.min(this._scalingTimeKick / this.scaleDuration, 1);
            const newScale = new Vec3();
            Vec3.lerp(newScale, this.initialScale, this.targetScale, t);
            this.ball.setScale(newScale);
            if (t >= 1) {
                this._scalingActiveKick = false;
            }
        }

        // Actualizar la escala para el rebote (volver al tamaño normal)
        if (this._scalingActiveBounce) {
            this._scalingTimeBounce += deltaTime;
            const t = Math.min(this._scalingTimeBounce / this.scaleDuration, 1);
            const newScale = new Vec3();
            // Interpolamos desde la escala pequeña (targetScale) hasta la normal (1,1,1)
            Vec3.lerp(newScale, this.targetScale, new Vec3(1, 1, 1), t);
            this.ball.setScale(newScale);
            if (t >= 1) {
                this._scalingActiveBounce = false;
            }
        }*/
    }

    protected start(): void {
        this.scheduleOnce(function () {
            this.kick();
        }, 5);
    }
}
