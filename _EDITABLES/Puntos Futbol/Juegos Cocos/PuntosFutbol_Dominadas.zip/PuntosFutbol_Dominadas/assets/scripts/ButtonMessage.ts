import { _decorator, Component, Button } from 'cc';
import { RebotePelota } from './RebotePelota';
const { ccclass, property } = _decorator;

@ccclass('ButtonMessage')
export class ButtonMessage extends Component {
    @property(RebotePelota)
    public manScore : RebotePelota = null;


    sendMessageToParent() {
        window.parent?.postMessage({
            score: this.manScore.ScoreText
        }, '*');
    }

    sendMessageToExit() {
        window.parent?.postMessage({
            state:'exit'
        }, '*');
    }

    sendMessageToReset() {
        window.parent?.postMessage({
            state:'reset'
        }, '*');
    }
}