import { _decorator, assetManager, CCBoolean, CCFloat, Component, instantiate, Node, Prefab, randomRangeInt, Vec3 } from 'cc';
import { Cannon } from './Cannon';
import { collision } from './collision';
const { ccclass, property } = _decorator;

@ccclass('spawn')
export class spawn extends Component {


    @property([Prefab])
    public assets : Prefab[] = [];
    @property(CCFloat) 
    public tiempo : number = 1;
    @property(Node)
    public balon : Node = null;
    @property(CCBoolean)
    public yaCreo : boolean = false;
    @property(collision)
    public game : collision = null;

    @property(Cannon)
        public tiro : Cannon = null;

    protected onLoad(): void {
        
    }
    start() {
       
    }
    StopSpawn(){
        this.unscheduleAllCallbacks();
    }
    Spawn(){
        
        this.spawnCall()
    }
    spawnCall(){
       
       
    }
    update(deltaTime: number) {
        if(this.tiro.yaTiro && !this.game.gameover)
        {
            this.tiempo -= deltaTime/20;
            if(this.tiempo < 1){
                this.tiempo = 1;
            }
            if(!this.yaCreo){
                this.yaCreo = true;
                this.scheduleOnce(function(){
                    const index = randomRangeInt(0, 18);
                    const node = instantiate(this.assets[index]);
                    node.setParent(this.node);
                    this.yaCreo=false;
                },this.tiempo)
                
            }

        }
        
        this.node.setWorldPosition(new Vec3(this.node.worldPosition.x,this.balon.worldPosition.y,this.node.worldPosition.z));
    }
}


