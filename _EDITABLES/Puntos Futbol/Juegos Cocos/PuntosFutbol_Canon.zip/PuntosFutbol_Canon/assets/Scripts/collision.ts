import { _decorator, Component, Collider, Label, ITriggerEvent, ICollisionEvent,  Node, RigidBody, Vec3, labelAssembler, CCInteger, CCFloat, Button } from 'cc';
import { spawn } from './spawn';
import { Cannon } from './Cannon';
import { ButtonMessage } from './ButtonMessage';
const { ccclass, property } = _decorator;

@ccclass('collision')
export class collision extends Component {


    @property(Cannon)
    public tiro : Cannon = null;
    @property(Label)
    public scoreNumber : Label = null;
    @property(Label)
    public scoreFinal : Label = null;
    @property(Node)
    public gameOver : Node = null;
    public gameover : boolean = false;
    @property(CCInteger)
    public score : number = 0;
    @property(CCInteger)
    public bonus : number = null;
    private elapsedTime : number = 0;
    @property(spawn)
    public spawnObject : spawn = null;

    protected onLoad(): void {
        this.gameOver.active = false;
        const collider = this.getComponent(Collider);
        if (collider) {
            // Suscribirse a los eventos de trigger
            collider.on('onTriggerEnter', this.onTriggerEnter, this);
            collider.on('onCollisionEnter', this.onCollisionEnter, this);
        }
    }
    onCollisionEnter(event:ITriggerEvent){
        const otherCollider = event.otherCollider;

        console.log(otherCollider.getGroup());
        if(otherCollider.getGroup() == 128){ 
            this.gameover=true;
            
            otherCollider.node.getComponent(Collider).enabled=false;
            console.log("Perdiste");
            const rgb = this.node.getComponent(RigidBody);
            rgb.useGravity=true;
            rgb.applyForce(new Vec3(0,-200,0));
            rgb.mass = 5;
            this.scheduleOnce(function(){
                this.gameOver.active = true;
                this.gameOver.getComponent(ButtonMessage).sendMessageToParent();
                rgb.useGravity=false;
                this.scoreFinal.string = this.scoreNumber.string;
                rgb.clearVelocity();
                this.spawnObject.StopSpawn();
            },5)
            
        }
    }
    onTriggerEnter(event: ICollisionEvent ){
        const otherCollider = event.otherCollider;

        console.log(otherCollider.getGroup());
        if(otherCollider.getGroup() == 64){ 
            console.log("Moneda");
           this.bonus = 50; 
          
           otherCollider.node.active=false;
        }
        
    }
    puntuacion(deltaTime){
        this.elapsedTime += (deltaTime * 1) + this.bonus;
        if(this.bonus>0){
            this.bonus=0;
        }
        this.score =  Math.floor(this.elapsedTime);
        this.scoreNumber.string = this.score.toString();
    }
    start() {

    }

    update(deltaTime: number) {
        if(this.tiro.yaTiro && !this.gameover){
            this.puntuacion(deltaTime);
        }
        
    }
}


