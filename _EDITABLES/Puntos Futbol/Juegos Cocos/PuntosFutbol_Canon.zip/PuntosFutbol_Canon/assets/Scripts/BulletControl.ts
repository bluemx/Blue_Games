// BallTouchControl.ts
import { _decorator, Component, Node, input, Input, EventTouch, Vec3, RigidBody } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('Bulletcontrol')
export class BallTouchControl extends Component {
    @property(Node)
    ball: Node = null;

    @property
    controlForce: number = 10; // ← Bajamos el valor base, más manejable

    @property
    maxHorizontalSpeed: number = 20;

    private ballBody: RigidBody = null;
    private velocity : Vec3 = new Vec3(0,0,0);

    onLoad() {
        input.on(Input.EventType.TOUCH_MOVE, this.onTouchMove, this);
        if (this.ball) {
            this.ballBody = this.ball.getComponent(RigidBody);
        }
    }

    onDestroy() {
        input.off(Input.EventType.TOUCH_MOVE, this.onTouchMove, this);
    }

    onTouchMove(event: EventTouch) {
        if (!this.ballBody) return;

        const delta = event.getDelta();
       
         this.ballBody.getLinearVelocity(this.velocity);

        // ⚠️ Aplica fuerza suavizada proporcional al movimiento del dedo
        const smoothedForceX = delta.x * this.controlForce * -0.01; // Multiplicador de suavizado
        const force = new Vec3(smoothedForceX, 0, 0);

        // ⚙️ Aplica fuerza solo si la velocidad horizontal no es demasiado alta
        if (Math.abs(this.velocity.x) < this.maxHorizontalSpeed) {
            this.ballBody.applyForce(force);
            this.ballBody.setAngularVelocity(new Vec3(40,0,0));
        }
    }
}
