import { _decorator, CCBoolean, Component, Node, Vec3 } from 'cc';
import { spawn } from './spawn';
const { ccclass, property } = _decorator;

@ccclass('CameraFollow')
export class CameraFollow extends Component {
    @property(Node)
    target: Node = null;

    @property
    followSpeed: number = 5;
    @property(spawn)
    public spawnObjects : spawn = null;
    @property
    zOffset: number = -5; // Despegue en eje Z (negativo = más lejos)
    @property(CCBoolean)
    public yaPuedeSeguir : boolean = false;
    @property(Node)
    public porteria : Node = null;

    private _initialOffset: Vec3 = new Vec3();

    start() {
        this.target = this.porteria;
        if (this.target) {
            this._calculateOffset();
        }
    }

    update(deltaTime: number) {
        if(this.yaPuedeSeguir){

            if (!this.target) return;
            
        // Aplica el offset actualizado
        const desiredPos = new Vec3();
        Vec3.add(desiredPos, this.target.worldPosition, this._initialOffset);

        // Interpolación suave
        const currentPos = this.node.worldPosition;
        const newPos = new Vec3();
        Vec3.lerp(newPos, currentPos, desiredPos, this.followSpeed * deltaTime);

        this.node.setWorldPosition(newPos);
        }
        
    }

    public follow(target: Node) {
        this.target = target;
        this._calculateOffset();
    }

    private _calculateOffset() {
       
        // Calcula la diferencia inicial y aplica el zOffset
        const camPos = this.node.worldPosition.clone();
        const targetPos = this.target.worldPosition.clone();
        this._initialOffset = camPos.subtract(targetPos);
        this._initialOffset.z += this.zOffset;
    }
}
