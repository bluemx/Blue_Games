import { _decorator, Component, Button } from 'cc';
import { collision } from './collision';
const { ccclass, property } = _decorator;

@ccclass('ButtonMessage')
export class ButtonMessage extends Component {
    @property(collision)
    public manScore : collision = null;


    sendMessageToParent() {
        window.parent?.postMessage({
            score: this.manScore.score
        }, '*');
    }
    sendMessageToExit() {
        window.parent?.postMessage({
            state: 'exit'
        }, '*');
    }
    sendMessageToRestart() {
        window.parent?.postMessage({
            status: 'reset'
        }, '*');
    }
}