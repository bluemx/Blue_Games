// Cannon.ts
import { _decorator, Component, Node, Prefab, instantiate, Vec3, RigidBody, input, Input, EventTouch, v3, CCBoolean, PostSettingsInfo } from 'cc';
import { CameraFollow } from './CameraFollow';
import { spawn } from './spawn';
const { ccclass, property } = _decorator;

@ccclass('Cannon')
export class Cannon extends Component {
    @property(Node)
    bulletNode: Node = null;

    @property
    launchForce: number = 1000;
    @property(CCBoolean)
    public yaTiro : boolean = false;


    @property
    launchAngle: number = 45;

    // Dentro de Cannon.ts
    @property({ type: spawn, tooltip:'camara principal' })
    cameraFollow: spawn = null;
    @property(Vec3)
    public posInicial : Vec3 = new Vec3(0,0,0);



    onLoad() {
        input.on(Input.EventType.TOUCH_START, this.shoot, this);
        
    }

    onDestroy() {
        input.off(Input.EventType.TOUCH_START, this.shoot, this);
    }
    reinicia(){
        console.log("Reiniciatiro");
        this.yaTiro = false;
        this.bulletNode.getComponent(RigidBody).clearVelocity();
        this.bulletNode.setWorldPosition(this.posInicial);
    }

    shoot() {
        if(!this.yaTiro){
            console.log("Dispara");
            //this.cameraFollow.getComponent(CameraFollow).followBullet(this.bulletNode);
            //this.bulletNode.setWorldPosition(this.node.getWorldPosition());
            this.cameraFollow.Spawn();

            const rad = this.launchAngle * Math.PI / 180;
            // Apunta en dirección Z (hacia adelante) con el ángulo
            const force = new Vec3(0, Math.sin(rad), Math.cos(rad)).multiplyScalar(this.launchForce);

            const rb = this.bulletNode.getComponent(RigidBody);
            rb.setAngularVelocity(new Vec3(0,40,0));
            rb.applyImpulse(force);
            this.scheduleOnce(function(){
                rb.useGravity = false;
                
            },2);
            
            this.yaTiro= true;
            
        }
        
    }
}
