// MoveZ.ts
import { _decorator, Component, Node, Vec3, CCInteger } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('moveObjects')
export class MoveZ extends Component {
    @property({ type: CCInteger, tooltip: 'Velocidad en unidades por segundo' })
    public speed: number = 5;

    @property({ type: CCInteger, tooltip: 'Posición Z límite para destruir' })
    public destroyZ: number = -10;

    update(deltaTime: number) {
        // Mover hacia negativo Z
        const pos = this.node.getPosition();
        pos.z -= this.speed * deltaTime;
        this.node.setPosition(pos);

        // Destruir si sobrepasa el límite
        if (pos.z < this.destroyZ) {
            this.node.destroy();
        }
    }
}
