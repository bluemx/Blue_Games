import { _decorator, CCBoolean, Animation, CCInteger, Component, randomRange, RigidBody, Collider, CCFloat, Vec3, find, Label, Node, randomRangeInt, SpriteRenderer, LightProbeSampler, Sprite, animation } from 'cc';
import { Portero } from './Portero';
import { ManagerSleccion } from './ManagerSeleccion';
import { SeleccionEquipo } from './SeleccionEquipo';
import { arrastrededo } from './arrastrededo';
import { Equipos } from './Equipos';
const { ccclass, property } = _decorator;

@ccclass('ManagerTurnos')
export class ManagerTurnos extends Component {

    @property([Node])
    public jugadores: Node[] = [];
    @property(Node)
    public balon : Node = null;
    @property(Equipos)
    public equipos : Equipos = null;
    @property(Node)
    public MS : Node = null;
    @property(CCInteger)
    private indexRondas : number = 0;
    @property(CCInteger)
    public LimiteRondas : number = 2;
    @property(CCInteger)
    public scorePlayer1 : number = 0;
    @property(CCInteger)
    public scorePlayer2 : number = 0;
    @property(CCInteger)
    public tiempoRonda : number = 0;
    @property([CCBoolean])
    public turnos :boolean[]=[false,false];
    @property(CCBoolean)
    public gameover : boolean = false;
    private yatiroPC : boolean = false;

    private x : number = 10;
    private contador : number = 3;

    @property(arrastrededo)
    public puedeArrastrar : arrastrededo = null;
    @property(Portero)
    public portero : Portero = null;
    @property(Node)
    public jugador : Node = null;


    @property([Node])
    public goal: Node[] = []; // La portería (o un punto representativo de ella)

    @property(Node)
    public posiciones: Node = null
    // Magnitud total de la fuerza que se desea aplicar
    @property(CCFloat)
    private kickForce: number = 500;

    // Ángulo de la patada en grados (determina el arco)
    @property
    kickAngle: number = 45;

    // Duración en segundos durante la cual se aplicará la fuerza
    @property
    kickDuration: number = 0.1;

    // Parámetros para la escala
    @property
    scaleDuration: number = 2.0; // Tiempo en segundos para el cambio de escala

    // Escala inicial (cuando el balón es "cercano") y escala final (cuando se aleja)
    @property(Vec3)
    initialScale: Vec3 = new Vec3(1, 1, 1);

    @property(Vec3)
    targetScale: Vec3 = new Vec3(0.3, 0.3, 0.3);
    // Variables internas para la patada
    private _kickTimeRemaining: number = 0;
    private _forceVector: Vec3 = new Vec3();

    

    // Variables internas para el escalado al patear
    private _scalingTimeKick: number = 0;
    private _scalingActiveKick: boolean = false;

    // Variables internas para el escalado al rebotar
    private _scalingTimeBounce: number = 0;
    private _scalingActiveBounce: boolean = false;
    @property([Node])
    public porteros : Node [] = [];
    private cambia : boolean = false;
    @property(CCBoolean)
    public turnoJugador : boolean = false;
   


    protected onLoad(): void {
        this.jugadores[0].active=false;
        this.jugadores[1].active=false; 
        this.jugadores[2].active=false;
        this.equipos = find("Equipos").getComponent(Equipos);
       
    }
    start() {
        for(let i = 0; i < this.porteros.length; i++){
            this.porteros[i].active = false;
        }
        this.MS = find("ManagerSeleccion-Jugadores"); 
        this.porteros[this.equipos.posPc].active = true;
        this.portero = this.porteros[this.equipos.posPc].getComponent(Portero);
        
        
        
                       
        this.jugador.getComponent(Sprite).spriteFrame = this.equipos.EquipoPlayer[this.equipos.posPlayer];
    //his.schedule(()=>this.juego(),5);
    }
    Rondaslistas(){
        let index = 0;
        for(let i = 0; i < this.turnos.length;i++){
            if(this.turnos[i]){
                index ++;
                if(index == this.turnos.length){
                    console.log("Ronda terminada");
                    this.turnos[0]=false;
                    this.turnos[1]=false;
                    this.indexRondas++;
                    if(this.indexRondas>this.LimiteRondas){
                        this.gameover=true;
                        this.puedeArrastrar.GameOver();
                        console.log("Fin del juego");
                    }
                }
            }
        }
    }

    juego(deltaTime : number){
        switch(this.MS.getComponent(ManagerSleccion).nameScene){
            case "Seleccion_1_jugador":
                if(!this.gameover){
                    if(!this.turnos[0]){
                        this.accion(0,deltaTime);
                        console.log("Puede tirar el primer jugador");
                        if(!this.cambia){
                            this.puedeArrastrar.puedeArrastrar = true;
                            this.cambia=true;
                            console.log("Cambia equipo jugador");
                            this.turnoJugador = true;
                            this.porteros[this.equipos.posPlayer].active = false;
                            this.jugador.getComponent(Sprite).spriteFrame = this.equipos.EquipoPlayer[this.equipos.posPlayer];
                            this.porteros[this.equipos.posPc].active = true;
                            this.portero = this.porteros[this.equipos.posPc].getComponent(Portero);
                            this.puedeArrastrar.Portero = this.portero.node;
                            
                        }
                        
                        this.acabatiro(0, deltaTime);
                
                    }
                    else if (!this.turnos[1] && this.turnos[0]){
                        this.accionPC(1, deltaTime);
                        if(!this.cambia){
                            this.cambia = true;
                            console.log("Cambia equipo pc");
                            this.porteros[this.equipos.posPc].active = false;
                            this.jugador.getComponent(Sprite).spriteFrame = this.equipos.EquipoPlayer[this.equipos.posPc];
                            this.porteros[this.equipos.posPlayer].active = true;
                            this.portero = this.porteros[this.equipos.posPlayer].getComponent(Portero);
                            this.puedeArrastrar.Portero = this.portero.node;
                       }
                        this.acabaTiroPC(1, deltaTime);
                    
                    }
                this.Rondaslistas();
                }
                break;
            case "Seleccion_2_jugador":
                if(!this.gameover ){

                    if(!this.turnos[0]){
                        this.accion(0, deltaTime);
                         console.log("Puede tirar el primer jugador");
                        if(!this.cambia){
                            this.puedeArrastrar.puedeArrastrar = true;
                            this.cambia=true;
                            console.log("Cambia equipo jugador");
                            this.turnoJugador = true;
                            this.porteros[this.equipos.posPlayer].active = false;
                            this.jugador.getComponent(Sprite).spriteFrame = this.equipos.EquipoPlayer[this.equipos.posPlayer];
                            this.porteros[this.equipos.posPc].active = true;
                            this.portero = this.porteros[this.equipos.posPc].getComponent(Portero);
                            this.puedeArrastrar.Portero = this.portero.node;
                            
                        }
                       
                        this.acabatiro(0, deltaTime);
                        
                
                    }
                else if (!this.turnos[1] && this.turnos[0]){
                    this.accion(2,deltaTime);
                     if(!this.cambia){
                            this.puedeArrastrar.puedeArrastrar = true;
                            this.cambia = true;
                            console.log("Cambia equipo jugador2");
                            this.porteros[this.equipos.posPc].active = false;
                            this.jugador.getComponent(Sprite).spriteFrame = this.equipos.EquipoPlayer[this.equipos.posPc];
                            this.porteros[this.equipos.posPlayer].active = true;
                            this.portero = this.porteros[this.equipos.posPlayer].getComponent(Portero);
                            this.puedeArrastrar.Portero = this.portero.node;
                       }
                    this.acabatiro(1, deltaTime);
                }
                this.Rondaslistas();
        
                }
                break;
        }
        
       

            
        
       
    }
    accion(pos : number, deltaime:number ){
        this.jugadores[pos].active=true;
        
       
        this.contador-= deltaime;
        //console.log("contador es iguala a" + this.contador.toString());
         
        if(this.contador<= 0 && this.jugadores[pos].active ){
            this.jugadores[pos].active = false;
         }
       // this.puedeArrastrar.resetea();
        
            //this.jugadores[pos].active=false;
            
     
        
    }
    accionPC(pos:number, deltaime: number){
         this.jugadores[pos].active=true;
         this.puedeArrastrar.puedeArrastrar=false;
         
        
         this.contador -= deltaime;

         
         if(this.contador<= 0 && this.jugadores[pos].active ){
            this.jugadores[pos].active = false;
         }
         //this.puedeArrastrar.resetea();
        
            //this.jugadores[pos].active=false;
        
    }
    acabatiro(pos : number, deltaTime : number){
        
        this.x -= deltaTime;
        //console.log(this.x);
        
        if(this.x<0){
            this.puedeArrastrar.resetea();
            this.puedeArrastrar.puedeArrastrar=false;
            this.turnos[pos]=true;
            this.cambia = false;
            this.x = 10;
            this.contador=3;
            this.turnoJugador = false;
        
        } 
        
        
    }
    acabaTiroPC(pos : number, deltaTime : number){
         
         this.x -= deltaTime;
        //console.log(this.x);
        if(this.x <= 5){
            this.tiroPC();
        }
        if(this.x<0){
        this.x = 10;
        this.turnos[pos]=true;
        this.puedeArrastrar.resetea();
        this.yatiroPC=false;
        this.contador = 3;
        this.cambia=false;
       
        } 
    }
   
    tiroPC(){
        if(!this.gameover && !this.yatiroPC){
            this.yatiroPC=true;
            // Reiniciar el contador de escalado para la patada
            this._scalingTimeKick = 0;
            this._scalingActiveKick = true;
            this.portero.PorteroAnim();
            // Establecer la escala inicial del balón
            this.balon.setScale(this.initialScale);

            // Obtener la posición del balón y la posición destino
            const ballPos = this.balon.worldPosition;
            let r = randomRangeInt(0,5);
            const goalPos = this.goal[r].worldPosition;
            this.puedeArrastrar.JugadorAnimacion(goalPos.x);
            // Calcular la dirección horizontal (plano XZ)
            const direction = new Vec3(goalPos.x - ballPos.x, 0, goalPos.z - ballPos.z);
            direction.normalize();

            // Ajustar aleatoriamente el ángulo y la fuerza
            this.kickAngle = randomRange(25.5, 27);
            const angleRad = this.kickAngle * (Math.PI / 180);
            this.kickForce = randomRange(800, 950);

            // Calcular las componentes de la fuerza
            const horizontalForce = this.kickForce * Math.cos(angleRad);
            const verticalForce = this.kickForce * Math.sin(angleRad);

            // Vector total de fuerza
            this._forceVector = new Vec3(
            direction.x * horizontalForce,
            verticalForce,
            direction.z * horizontalForce
        );

        // Reiniciar el tiempo durante el cual se aplicará la fuerza
        this._kickTimeRemaining = this.kickDuration;

        // Después de 8 segundos, reiniciamos el balón para el siguiente tiro
       
        }
        
        
    }
    update(deltaTime: number) {
        
        this.juego(deltaTime);
         if (this._kickTimeRemaining > 0) {
            const rb = this.balon.getComponent(RigidBody);
            if (rb) {
                const frameForce = new Vec3(
                    this._forceVector.x * (deltaTime / this.kickDuration),
                    this._forceVector.y * (deltaTime / this.kickDuration),
                    this._forceVector.z * (deltaTime / this.kickDuration)
                );
                rb.applyForce(frameForce, new Vec3(0, 0, 0));
                const angular = randomRange(-15, 15);
                rb.setAngularVelocity(new Vec3(0, angular, 0));
            }
            this._kickTimeRemaining -= deltaTime;
        }
    }
}


