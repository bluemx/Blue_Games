import { _decorator, CCInteger, CCString, SpriteFrame, director, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('Equipos')
export class Equipos extends Component {
    public static _instance : Equipos = null;
    @property(CCInteger)
    public posPlayer : number = 0;
    @property(CCInteger)
    public posPc : number = 0;
    @property(CCString)
    public nameequipo1 : String = "";
    @property(CCString)
    public nameequipo2 : String = "";
    @property([SpriteFrame])
    public EquipoPlayer : SpriteFrame[] = [];

    protected onLoad(): void {
          if (Equipos._instance) {
                    // Si ya hay uno, destruir este nuevo duplicado
                    this.node.destroy();
                    return;
                }
                Equipos._instance = this;
                director.addPersistRootNode(this.node);
    }
    start() {

    }

    update(deltaTime: number) {
        
    }
}


