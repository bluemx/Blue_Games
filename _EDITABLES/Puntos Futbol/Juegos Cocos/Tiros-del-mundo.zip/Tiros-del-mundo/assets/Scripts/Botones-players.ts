import { _decorator, Component, SpriteFrame, Button, Node, find } from 'cc';
import { CambioEscena } from './CambioEscena';
import { ManagerSleccion } from './ManagerSeleccion';
const { ccclass, property } = _decorator;

@ccclass('Botones_players')
export class Botones_players extends Component {

    @property([SpriteFrame])
    public botones : SpriteFrame[] = [];
    @property(CambioEscena)
    public CambioBoton : CambioEscena = null;
    @property(ManagerSleccion)
    public MS : ManagerSleccion = null;



    start() {
        this.MS = ManagerSleccion._instance;
    }
     CambioName(){
        console.log("Cambie el string??");
        this.MS.nameScene = "Seleccion_1_jugador";
        this.CambioBoton.name2 = this.MS.nameScene;
         find("Canvas/fondo/1 jugador").getComponent(Button).normalSprite=this.botones[0];
        find("Canvas/fondo/Multijugador").getComponent(Button).normalSprite = this.botones[3];
        
        
    }
    cambioName2(){
        console.log("Cambie el string??");
        this.MS.nameScene = "Seleccion_2_jugador";
        this.CambioBoton.name2 = this.MS.nameScene;
        find("Canvas/fondo/1 jugador").getComponent(Button).normalSprite=this.botones[1];
        find("Canvas/fondo/Multijugador").getComponent(Button).normalSprite = this.botones[2];
    }

    update(deltaTime: number) {
        
    }
}


