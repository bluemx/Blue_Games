import { _decorator, Component, Button, find } from 'cc';
import { ManagerTurnos } from './ManagerTurnos';
import { ManagerSleccion } from './ManagerSeleccion';

const { ccclass, property } = _decorator;

@ccclass('ButtonMessage')
export class ButtonMessage extends Component {
    @property(ManagerTurnos)
    public manScore : ManagerTurnos = null;
   

    protected onLoad(): void {
        
    }


    sendMessageToParent() {
                const score = this.manScore.scorePlayer1;
                window.parent?.postMessage({
                score: score
            }, '*');
        
    }
    sendMessageToParent2(){
         const score1 = this.manScore.scorePlayer1 + this.manScore.scorePlayer2;
                window.parent?.postMessage({
                score: score1
            }, '*');
    }
    sendMessageToExit() {
        window.parent?.postMessage({
            state: 'exit'
        }, '*');
    }
    sendMessageToRestart() {
        window.parent?.postMessage({
            state: 'reset'
        }, '*');
    }
     sendMessageToStart() {
        window.parent?.postMessage({
            state: 'start'
        }, '*');
    }
}