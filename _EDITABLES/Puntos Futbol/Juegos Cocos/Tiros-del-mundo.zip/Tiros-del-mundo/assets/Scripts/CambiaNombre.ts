import { _decorator, Component, find, Label, Node } from 'cc';
import { Equipos } from './Equipos';
import { Portero } from './Portero';
const { ccclass, property } = _decorator;

@ccclass('CambiaNombre')
export class CambiaNombre extends Component {
    @property(Equipos)
    public equiposNombre : Equipos = null;

    @property(Label)
    public name1 : Label = null;
    @property(Label)
    public name2: Label = null;

    @property(Label)
    public name1final : Label = null;
     @property(Label)
    public name2final : Label = null;


    protected onLoad(): void {
        this.equiposNombre = find("Equipos").getComponent(Equipos);
        this.name1.string = this.equiposNombre.nameequipo1.toString() + " :";
        this.name2.string = this.equiposNombre.nameequipo2.toString() + " :";
        this.name1final.string = this.equiposNombre.nameequipo1.toString() + " :";
        this.name2final.string = this.equiposNombre.nameequipo2.toString() + " :";
    }
    start() {

    }

    update(deltaTime: number) {
        
    }
}


