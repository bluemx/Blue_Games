import { _decorator, CCInteger, Component, find, Node } from 'cc';
import { SeleccionEquipo } from './SeleccionEquipo';
const { ccclass, property } = _decorator;

@ccclass('PoscionBoton')
export class PoscionBotono extends Component {
    @property(CCInteger)
    public pos : number = 0;
    @property(SeleccionEquipo)
    public ManagerEquipos : SeleccionEquipo = null;

    protected onLoad(): void {
        this.ManagerEquipos = find("ManagerSeleccion").getComponent(SeleccionEquipo);
    }
    start() {

    }

    SetPosSeleccion(){
        console.log("la posicion es  "+ this.pos);
        this.ManagerEquipos.posSeleccion = this.pos;
        this.ManagerEquipos.CambiaSeleccion();

        
    }
   SetPosSeleccion2(){
        console.log("la posicion es  "+ this.pos);
        this.ManagerEquipos.posSeleccion = this.pos;
        this.ManagerEquipos.CambiaSeleccion2();

        
    }
    update(deltaTime: number) {
        
    }
}


