import { _decorator, Component, Node, UITransform, Touch, Vec2, Vec3, Graphics, math, RigidBody, Animation, CCInteger, CCBoolean } from 'cc';
import { Portero } from './Portero';
import { ManagerTurnos } from './ManagerTurnos';
import { ButtonMessage } from './ButtonMessage';
import { ManagerSleccion } from './ManagerSeleccion';
const { ccclass, property } = _decorator;

@ccclass('arrastrededo')
export class arrastrededo extends Component {

    @property(Node)
    public Balon : Node = null;

    @property(Vec3)
    public posui : Vec3 = new Vec3;

    private flecha : Graphics = null;

    private lineWidth : number = 5;
    private arrowLength : number = 20;
    private arrowAngle : number =12/Math.PI
    @property(ManagerSleccion)
    public mS : ManagerSleccion = null;
    @property(Vec2)
    public posInicial : Vec2  = new Vec2;
    @property (Vec2)
    public posFinal : Vec2 = new Vec2;
    @property(Node)
    public Portero : Node = null;
    @property(Vec3)
    public posicionInicial : Vec3 = null;
    @property(Node)
    public jugadorAnim : Node = null;
    @property(CCBoolean)
    public puedeArrastrar : boolean = false;
    @property(Node)
    public GameO : Node = null;
    @property(CCInteger)
    public tiros : number = 0;
    @property(Node)
    public manmagerturnos : Node = null;
    @property([Node])
    public mensajes : Node [] = [];
    protected onLoad(): void {

        
        this.GameO.active=false;
        this.flecha = this.node.getComponent(Graphics);
        this.node.on(Node.EventType.TOUCH_START, this.onStart, this)
        this.node.on(Node.EventType.TOUCH_MOVE, this.onMove, this)
        this.node.on(Node.EventType.TOUCH_END, this.onMoveEnd, this)
        this.node.on(Node.EventType.TOUCH_CANCEL, this.onMoveEnd,this)
        this.mS = ManagerSleccion._instance;
    }
    onStart(event: Touch){
        if(this.puedeArrastrar){
            this.posui = new Vec3(0,0,0);
            this.posInicial = new Vec2(0, 0);
        }
      

    }
    onMove(event:Touch){
        if(this.puedeArrastrar){
            const screepos = event.getUILocation()
            this.posui= new Vec3(screepos.x,screepos.y,0)
        
            this.posFinal = event.getUILocation()
            this.posFinal.x -= 300;
            this.DibujaFlecha(this.posInicial,new Vec2(this.posFinal.x, this.posFinal.y))
        }
        

    }
    onMoveEnd(event:Touch){
        
        if(this.puedeArrastrar){
            this.posFinal = event.getUILocation()
        this.posFinal.x -= 300;
        this.JugadorAnimacion(this.posFinal.x);
        this.DibujaFlecha(this.posInicial,new Vec2(this.posFinal.x , this.posFinal.y))
        this.Balon.getComponent(RigidBody).setLinearVelocity(new Vec3((this.posFinal.x)/-65,this.posFinal.y/80,this.posFinal.y/25))
        this.Balon.getComponent(RigidBody).setAngularVelocity(new Vec3(1,0,-1))
        this.Portero.getComponent(Portero).PorteroAnim();
        this.flecha.clear( );
        //this.node.active=false;
        
        this.tiros++;
        this.puedeArrastrar = false;
        }
        
       

    }
    JugadorAnimacion( x : number){
        if(x<=0){
            this.jugadorAnim.getComponent(Animation).play("IZQJUGADOR");
        }
        else{
            this.jugadorAnim.getComponent(Animation).play("DERJUGADOR");
        }
        
    }
    GameOver(){
        this.GameO.active=true;
        const manager = this.manmagerturnos.getComponent(ManagerTurnos);
        if(this.mS.nameScene == "Seleccion_1_jugador"){
            this.GameO.getComponent(ButtonMessage).sendMessageToParent();
        }
        else{
            this.GameO.getComponent(ButtonMessage).sendMessageToParent2();
        }
        
        if(manager.scorePlayer1 != 0 && manager.scorePlayer2 != 0 && manager.scorePlayer1 == manager.scorePlayer2){
            this.mensajes[0].active = true;
            this.mensajes[1].active = false;
            this.mensajes[2].active = true;
            this.mensajes[3].active = false;
            return;
        }
        if(manager.scorePlayer1 == 0 && manager.scorePlayer2 == 0){
            this.mensajes[0].active = false;
            this.mensajes[1].active = true;
            this.mensajes[2].active = false;
            this.mensajes[3].active = true;
            return;
        }
        else if(manager.scorePlayer1 > manager.scorePlayer2){
            this.mensajes[0].active = true;
            this.mensajes[1].active = true;
            this.mensajes[2].active = false;
            this.mensajes[3].active = false;
            return;
        }
        else{
            this.mensajes[0].active = false;
            this.mensajes[1].active = false;
            this.mensajes[2].active = true;
            this.mensajes[3].active = true;
            return;
        }
        
        
    }
    resetea(){
        this.Balon.getComponent(RigidBody).clearVelocity();
        this.Balon.getComponent(RigidBody).clearForces();
        this.Balon.setPosition(this.posicionInicial);
        this.Portero.getComponent(Portero).Idle();
        this.jugadorAnim.getComponent(Animation).play("IDLJUGADOR");
    }
    DibujaFlecha(inicio : Vec2, final : Vec2  ){
        this.flecha.clear( );

        this.flecha.moveTo(inicio.x, inicio.y)
        this.flecha.lineTo(final.x,final.y)
        //calcular la direccion de la linea 
        let angle = Math.atan2(final.y - inicio.y , final.x -inicio.x)

        //dibuja primera linea de flecha 
        this.flecha.moveTo(final.x, final.y )
        this.flecha.lineTo (
            final.x + this.arrowLength * Math.cos(angle - this.arrowAngle),
            final.y + this.arrowLength * Math.sin(angle - this.arrowAngle)
        )
       
        this.flecha.moveTo(final.x, final.y )
        this.flecha.lineTo (
            final.x +  this.arrowLength * Math.cos(angle + this.arrowAngle),
            final.y + this.arrowLength * Math.sin(angle + this.arrowAngle)
        )
       
       
        this.flecha.stroke();
    }
    start() {
         this.Portero = this.manmagerturnos.getComponent(ManagerTurnos).porteros[this.manmagerturnos.getComponent(ManagerTurnos).equipos.posPc];
    }

    update(deltaTime: number) {
        
    }
}


