import { _decorator, Component, director, SceneAsset, Node, CCString } from 'cc';
import { SeleccionEquipo } from './SeleccionEquipo';
import { ManagerTurnos } from './ManagerTurnos';
import { ManagerSleccion } from './ManagerSeleccion';
import { Equipos } from './Equipos';
const { ccclass, property } = _decorator;

@ccclass('CambioEscena')
export class CambioEscena extends Component {
    @property(CCString)
    public name2 : String = "";
    
    onLoad() {
        // Agrega un evento de clic al botón
       
       this.cambio();
    }

    //cc.director.preloadScene("table", function () {
    //    cc.log("Next scene preloaded");
    //});
    cambio() {
       
            var progress = 0;
            director.preloadScene(this.name2.toString(), (completedCount: number, totalCount: number, item: any) => {
            progress = completedCount / totalCount;
        }, (error: Error, asset: SceneAsset) => {
            //do something after preloaded scene
            //console.log("YA PRECARGUE LA ESCENA " + this.name2);
        });
    }
   
   Carga(){
       director.loadScene(this.name2.toString());
   }
   Carga2(){
        if(Equipos._instance.posPc >-1){
            director.loadScene(this.name2.toString());
        }
   }
}


