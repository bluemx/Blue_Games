import { _decorator, Component, Node, Collider, ITriggerEvent, Label, Prefab, instantiate, find } from 'cc';
import { ManagerTurnos } from './ManagerTurnos';
const { ccclass, property } = _decorator;

@ccclass('Golazo')
export class Golazo extends Component {

    @property(Node)
    public AnimGol : Node = null;
    @property(ManagerTurnos)
    public manager : ManagerTurnos = null;
    @property(Label)
    public score : Label = null;
    @property(Label)
    public scorePC : Label = null;
    @property(Label)
    public ScoreFinal : Label = null;
    @property(Label)
    public scoreFinalPc : Label = null;
    private scorepctext : number = 0;
    private scoreText : number = 0;
    @property(Prefab)
    public Particulas : Prefab = null;
    @property(Node)
    public canvas : Node = null;

    protected onLoad(): void {
        this.AnimGol.active=false;

        const collider = this.getComponent(Collider);
        if (collider) {
            // Suscribirse a los eventos de trigger
            collider.on('onTriggerEnter', this.onTriggerEnter, this);
        }
    }
    onTriggerEnter(event: ITriggerEvent ){

        const otherCollider = event.otherCollider;

        //console.log(otherCollider.getGroup());
        if(otherCollider.getGroup()==4){
            this.AnimGol.active=true;
            this.scheduleOnce(function(){
                this.AnimGol.active=false;
                if(this.manager.turnoJugador){
                    this.manager.scorePlayer1++;
                    this.scoreText += 1;
                    this.score.string = this.scoreText.toString();
                    this.ScoreFinal.string=this.score.string;
                }
                else{
                    this.manager.scorePlayer2 ++;
                    this.scorepctext += 1;
                    this.scorePC.string = this.scorepctext.toString();
                    this.scoreFinalPc.string=this.scorePC.string;
                }
                
                let node1 = instantiate(this.Particulas);
                node1.setParent(this.canvas);
                

            },1.5);

            
        }

    }
    start() {
        this.manager = find("ManagerTurnos").getComponent(ManagerTurnos);
    }

    update(deltaTime: number) {
        
    }
}


