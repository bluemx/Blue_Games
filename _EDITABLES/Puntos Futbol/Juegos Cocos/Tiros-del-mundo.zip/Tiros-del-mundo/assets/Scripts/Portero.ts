import { _decorator, animation, Component, Node, Animation, randomRangeInt } from 'cc';
import { arrastrededo } from './arrastrededo';
const { ccclass, property } = _decorator;

@ccclass('Portero')
export class Portero extends Component {
    @property(Animation)
    public portero : Animation = null;
    @property(arrastrededo)
    public PosX : arrastrededo = null;


    protected onLoad(): void {
        this.portero = this.node.getComponent(Animation);
      //  this.portero.play("Idle");
    }
    Idle(){
        this.portero.play("Idle");
    }
    PorteroAnim(){
        //console.log("Anima portero");
        this.scheduleOnce(function(){
            let x = randomRangeInt(0,10);
           

            switch(x){
                case 0: 
                    console.log("no hice nada");
                    this.portero.play("SALTO")
                break;
                case 1: 
                this.portero.play("DER")
                //console.log("derecha");
                break;
                case 2: 
                this.portero.play("IZQ")
                //console.log("Izquierda");
                break;
                case 3:
                    this.portero.play("IZQ")
                    //console.log("Izquierda");
                break;
                case 4: 
                this.portero.play("DER")
                //console.log("derecha");
                break;
                case 5:
                    this.portero.play("IZQ")
                   // console.log("Izquierda");
                break;
                case 6: this.portero.play("DER")
                     //console.log("derecha");
                break;
                case 7: 
                this.portero.play("DER")
                     //console.log("derecha");
                     break;

                case 8: this.portero.play("IZQ")
                //console.log("Izquierda");
                break;
                case 9: this.portero.play("IZQ")
                //console.log("Izquierda");
                break;
                case 10: this.portero.play("SALTO");
                break;

            }

            //console.log("ANimeeee?");
        },.3);
       
    }
    start() {
        

    }

    update(deltaTime: number) {
        
    }
}


